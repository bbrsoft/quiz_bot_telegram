const http = require('http');
const https = require('https');
const querystring = require('querystring');

// Variabel global untuk menyimpan data pengguna
let userData = '';
let comm = '';

// Fungsi untuk mengirim permintaan POST
function st_coman(user_chat_id) {
    
    // Encode data sebagai URL parameter
    const data = querystring.stringify({
        chat_id: user_chat_id
    });

    const options = {
        hostname: 'quizamon.pundirupiah.my.id',
        port: 443,
        path: '/telegram.php?method=send_start_command',
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',  // Header sesuai dengan format data
            'Content-Length': data.length
        }
    };

    const req = https.request(options, res => {
        let responseBody = '';
        res.on('data', chunk => {
            responseBody += chunk;
        });

        res.on('end', () => {
            comm = 'Do Comman!!'+ responseBody;
            console.log('Command /start sent:', responseBody);
        });
    });

    req.on('error', error => {
        console.error('Error sending /start command:', error);
    });

    req.write(data);
    req.end();
}

// Fungsi untuk mengambil data pengguna (GET request)
function fetchUsers() {
    console.log('Start fetchUsers!!');
    const options = {
        hostname: 'quizamon.pundirupiah.my.id',
        port: 443,
        path: '/telegram.php?method=get_users',
        method: 'GET',
    };

    https.get(options, res => {
        let responseBody = '';
        res.on('data', chunk => {
            responseBody += chunk;
        });

        res.on('end', () => {
            console.log('Response received from GET request:', responseBody); // Log response
            try {
                const users = JSON.parse(responseBody);
                if (users && users.length > 0) {
                    userData = ''; // Reset data pengguna
                    users.forEach(user => {
                        userData += `User ID: ${user.username} - Chat ID: ${user.chat_id} - Jeda: ${user.jeda}\n`;
                        if (user.chat_id) {
                            st_coman(user.chat_id);
                        }
                    });
                    console.log('User data updated:', userData); // Log updated userData
                } else {
                    userData = 'No user data available or response is null.';
                }
            } catch (error) {
                console.error('Error parsing user data:', error);
                userData = 'Error parsing user data.';
            }
        });
    }).on('error', error => {
        console.error('Error getting user data for command:', error);
        userData = 'Error getting user data.';
    });
}

// Set interval untuk memanggil fungsi fetchUsers setiap 10 detik
setInterval(fetchUsers, 10000);

// Server HTTP sederhana
const server = http.createServer(function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    const message = 'It works Bot Quizamon!\n',
          version = 'NodeJS ' + process.versions.node + '\n',
          data = 'User Data:\n' + userData;
          commen = 'Comman :\n' + comm;
    res.end([message, version, data, commen].join('\n'));
});

// Menjalankan server di port yang ditentukan (contoh: 3000)
server.listen(3000, () => {
    console.log('Server running on port 3000');
});
