<?php
class PostingModel {
    private $conn;
    private $table_name = "posting";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function ambilpertanyaan($idPertanyaan) {
        $query = "SELECT title, content FROM " . $this->table_name . " WHERE id = '$idPertanyaan'";
        $result = $this->conn->query($query);
    
        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Mengembalikan data sebagai array asosiatif
        } else {
            return null; // Kembalikan null jika tidak ada data ditemukan
        }
    }

    public function get_questions($language_id, $limit) {
        $query = "SELECT id, title, content FROM " . $this->table_name . " WHERE thread = '$language_id'  ORDER BY RAND() LIMIT $limit";
        $result = $this->conn->query($query);

        $questions = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $questions[] = $row;
            }
        }

        return $questions;
    }
}
?>
