<?php
class UserModel {
    private $conn;
    private $table_name = "users";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function checkUser($user_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE email = '$user_id'";
        $result = $this->conn->query($query);
        return $result->num_rows > 0;
    }

    public function register($data) {
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $role = 'user';
        $is_admin = 0;
        $question_sesi = 'Open';
        $jeda = 0;
        $l = 1;
        $r = 10;
        $status_game = 0;
        $current_round = 0;
        $questions = '';

        $query = "INSERT INTO " . $this->table_name . " (ip_address, username, password, email, role, created_on, phone, chat_id, group_id, is_admin, question_sesi, jeda, l, r, status_game, current_round, questions)
                  VALUES ('$ip_address', '{$data['username']}', '{$data['password']}', '{$data['email']}', 'user', '{$data['created_on']}', '{$data['phone']}', '{$data['chat_id']}', '{$data['group_id']}', 0, 'Open', 0, 1, 10, 0, 0, '')";
        
        if (!$this->conn->query($query)) {
            die("Execute failed: (" . $this->conn->errno . ") " . $this->conn->error);
        }
    }

    public function update($user_id, $data) {
        $query = "UPDATE " . $this->table_name . " SET chat_id = '{$data['chat_id']}', group_id = '{$data['group_id']}', is_admin = '{$data['is_admin']}' WHERE email = '$user_id'";
        
        if (!$this->conn->query($query)) {
            die("Update failed: (" . $this->conn->errno . ") " . $this->conn->error);
        }
    }

    public function dataMis($chat_id) {
        $query = "SELECT question_sesi, questions, jeda, current_round, l, r, score, jawaban_kosong FROM " . $this->table_name . " WHERE chat_id = '$chat_id' AND is_admin = 1";
        $result = $this->conn->query($query);

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        } else {
            return null; // Kembalikan null jika tidak ada data ditemukan
        }
    }

    public function dataAnswer($chat_id) {
        // Logika untuk mengambil data jawaban user dari database
        // Sesuaikan query ini dengan skema database Anda
        $query = "SELECT * FROM users WHERE chat_id = '$chat_id' ORDER BY time_answer ASC";
        $result = $this->conn->query($query);
        $answers = [];
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $answers[] = $row;
            }
        }
        return $answers;
    }
    
    public function get_ranking_top_datatables()
   {
         $query = "SELECT * FROM users ORDER BY coin DESC LIMIT 10";
    $result = $this->conn->query($query);

    if ($result->num_rows > 0) {
        return $result->fetch_all(MYSQLI_ASSOC); // Mengembalikan semua hasil sebagai array asosiatif
    } else {
        return null; // Kembalikan null jika tidak ada data ditemukan
    }
   }

    public function dataAns($chat_id) {
        // Logika untuk mengambil data ans dari database
        // Sesuaikan query ini dengan skema database Anda
        $query = "SELECT * FROM users WHERE chat_id = '$chat_id' AND user_answer <> '' ";
        $result = $this->conn->query($query);

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        } else {
            return null; // Kembalikan null jika tidak ada data ditemukan
        }
    }
    
public function get_top_ranking_users()
{
    // Pastikan untuk mendefinisikan $chat_id di tempat lain atau tambahkan sebagai parameter fungsi jika diperlukan
    $query = "SELECT * FROM users ORDER BY coin DESC LIMIT 10";
    $result = $this->conn->query($query);
    
    if ($result->num_rows > 0) {
        $users = [];
        while($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        return $users; // Kembalikan array yang berisi 10 pengguna teratas
    } else {
        return null; // Kembalikan null jika tidak ada data ditemukan
    }
}
      public function update_user_fields($chat_id, $fields) {
        $set_clause = [];
        foreach ($fields as $field => $value) {
            $set_clause[] = "$field = '$value'";
        }
        $set_clause_str = implode(', ', $set_clause);

        $query = "UPDATE " . $this->table_name . " SET $set_clause_str WHERE chat_id = '$chat_id' AND is_admin = 1";
        
        if (!$this->conn->query($query)) {
            die("Update failed: (" . $this->conn->errno . ") " . $this->conn->error);
        }
    }
    
public function AdminApply($user_id, $data_reg) {
    // Convert the $data_reg array to an SQL SET string
    $setPart = "";
    foreach ($data_reg as $key => $value) {
        $setPart .= "$key = '$value', ";
    }
    // Remove the trailing comma and space
    $setPart = rtrim($setPart, ', ');

    // Prepare the SQL query
    $query = "UPDATE " . $this->table_name . " SET $setPart WHERE email = ?";
    
    // Use prepared statements for safety
    $stmt = $this->conn->prepare($query);
    $stmt->bind_param('s', $user_id);
    
    // Execute the query and handle errors
    if (!$stmt->execute()) {
        die("Update failed: (" . $stmt->errno . ") " . $stmt->error);
    }
    
    $stmt->close(); // Close the statement
}


public function AdminDeny($chat_id, $data_reg) {
    // Convert the $data_reg array to an SQL SET string
    $setPart = "";
    foreach ($data_reg as $key => $value) {
        $setPart .= "$key = '$value', ";
    }
    // Remove the trailing comma and space
    $setPart = rtrim($setPart, ', ');

    // Prepare the SQL query
    $query = "UPDATE " . $this->table_name . " SET $setPart WHERE chat_id = ?";
    
    // Use prepared statements for safety
    $stmt = $this->conn->prepare($query);
    $stmt->bind_param('s', $chat_id);
    
    // Execute the query and handle errors
    if (!$stmt->execute()) {
        die("Update failed: (" . $stmt->errno . ") " . $stmt->error);
    }
    
    $stmt->close(); // Close the statement
}
    
     public function update_user_fields_by_email($user_id, $fields) {
        $set_clause = [];
        foreach ($fields as $field => $value) {
            $set_clause[] = "$field = '$value'";
        }
        $set_clause_str = implode(', ', $set_clause);

        $query = "UPDATE " . $this->table_name . " SET $set_clause_str WHERE email = '$user_id'";
        
        if (!$this->conn->query($query)) {
            die("Update failed: (" . $this->conn->errno . ") " . $this->conn->error);
        }
    }
    
 public function get_data_chat_p() {
    $query = "SELECT * FROM users WHERE question_sesi = 'Closed' AND is_admin= 1";
    $result = $this->conn->query($query);

    if ($result->num_rows > 0) {
        $data = $result->fetch_all(MYSQLI_ASSOC);

        // Menghilangkan duplikat berdasarkan chat_id
        $uniqueData = [];
        foreach ($data as $row) {
            $uniqueData[$row['chat_id']] = $row;
        }

        return array_values($uniqueData); // Mengembalikan data sebagai array
    } else {
        return []; // Kembalikan array kosong jika tidak ada data ditemukan
    }
}


public function cekQ($chat_id){
    $query = "SELECT * FROM users WHERE questions <> '' AND is_admin= 1";
    $result = $this->conn->query($query);

    if ($result->num_rows > 0) {
        return true;
    }else{
        return false;
    }
}
    
     public function update_an_kosong($chat_id,$data){
        
        $query = "UPDATE " . $this->table_name . " SET $data WHERE chat_id = '$chat_id'";
        
        if (!$this->conn->query($query)) {
            die("Update failed: (" . $this->conn->errno . ") " . $this->conn->error);
        }
    }
    
    public function get_current_coin($user_id) {
        $query = $this->conn->prepare("SELECT coin, answer FROM users WHERE email = ?");
            $query->bind_param("s", $user_id); // 's' untuk string
            $query->execute();
            
            $result = $query->get_result();
            
            if ($result->num_rows > 0) {
                return $result->fetch_assoc(); // Mengembalikan 1 baris sebagai array asosiatif
            } else {
                return []; // Kembalikan array kosong jika tidak ada data ditemukan
            }
    }
    
    public function update_user_jawab($user_id, $data) {
        $updateFields = [];
        foreach ($data as $key => $value) {
            // Cek apakah nilai adalah array atau bukan
            if (is_array($value)) {
                $value = json_encode($value); // Ubah array menjadi string JSON
            }
            // Escape the value to prevent SQL injection
            $escaped_value = $this->conn->real_escape_string($value);
            $updateFields[] = "$key = '$escaped_value'";
        }
        $updateString = implode(', ', $updateFields);
    
        $query = "UPDATE " . $this->table_name . " SET $updateString WHERE email = '$user_id'";
        
        if (!$this->conn->query($query)) {
            die("Update failed: (" . $this->conn->errno . ") " . $this->conn->error);
        }
}


    
}
?>
