<div class="container">
   <div class="row">
      <div class="col">
         <h3 class="page-header"><?= $title ?></h3>
      </div>
   </div>

    <button class="btn btn-success btn-sm mt-3"onclick="addnewmember()">
      <i class="fas fa-plus"></i> Tambah
   </button>
   <button class="btn btn-outline-secondary btn-sm mt-3"onclick="reload_table()">
      <i class="fas fa-sync-alt"></i> Reload
   </button>

   <br><br>

   <div class="table-responsive">
      <table id="tableMember" class="table table-striped table-bordered"  cellspacing="0" width="100%">
         <thead>
         <tr>
            <th>#</th>
            <th>Username</th>
            <th>Action</th>
         </tr>
         </thead>
         <tbody>
         
         </tbody>
      </table>
   </div>

</div>

<!-- Modal -->
<div class="modal fade" id="modalMember" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
         <h5 class="modal-title" id="modal-title">Add Coin</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
         </button>
         </div>
         <div class="modal-body">
            <form action="#" class="form-horizontal" id="form">
               <input type="hidden" name="id">

               <div class="form-group row">
                  <label for="web_name" class="col-sm-3 col-form-label">Email</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="member_name">
                  </div>
               </div> 


              <div class="form-group row">
                  <label for="member_coin_display" class="col-sm-3 col-form-label">Member Coin</label>
                  <div class="col-sm-9">
                     <input type="text" class="form-control" name="member_coin_display" readonly>
                  </div>
               </div> 

               <div class="form-group row">
                  <label for="web_address" class="col-sm-3 col-form-label">Add Coin</label>
                  <div class="col-sm-9">
                  <input type="number" min="0" max="20000000" class="form-control" name="member_coin_input" value="0">
                  </div>
               </div> 


            </form>
         </div>
         <div class="modal-footer">
         <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Tutup</button>
         <button type="button" class="btn btn-sm btn-primary" onclick="save()" id="btn_save">Simpan</button>
         </div>
      </div>
   </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalAddMember" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
         <div class="modal-header">
         <h5 class="modal-title" id="modal-title">Create New Member</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
         </button>
         </div>
         <div class="modal-body">
            <form action="#" class="form-horizontal" id="form">

               <div class="form-group row">
                  <label for="web_name" class="col-sm-3 col-form-label">Username</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="member_username_add">
                  </div>
               </div> 
               
               <div class="form-group row">
                  <label for="web_name" class="col-sm-3 col-form-label">Email</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="member_email_add">
                  </div>
               </div> 
               
               <div class="form-group row">
                  <label for="web_name" class="col-sm-3 col-form-label">Coin</label>
                  <div class="col-sm-9">
                  <input type="number" class="form-control" name="member_coin_add" value="0">
                  </div>
               </div> 


            </form>
         </div>
         <div class="modal-footer">
         <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Tutup</button>
         <button type="button" class="btn btn-sm btn-primary" onclick="save()" id="btn_save">Simpan</button>
         </div>
      </div>
   </div>
</div>