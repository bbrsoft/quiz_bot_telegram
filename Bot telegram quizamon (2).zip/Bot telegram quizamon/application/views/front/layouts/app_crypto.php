<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cryptoper</title>
	<link rel="icon" href="<?= base_url("images/favicon/$favicon->photo") ?>" type="image/png">
    <!--<link rel="stylesheet" href="<?= base_url() ?>assets/front/css/mobile-style.css">-->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   <style>
       * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: black;
}


.app {
    display: flex;
    flex-direction: column;
    height: 95vh;
    width: 375px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #fff;
    border-radius: 15px;
    overflow: hidden;
}

.app-header {
    background-color: #2a124d;
    color: white;
    padding: 1rem;
    text-align: center;
}

.app-content {
    flex: 1;
    overflow-y: auto;
    padding: 1rem;
}

.header-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.header-row .left {
    text-align: left;
}

.header-row .right {
    text-align: right;
    font-size: 15px;
    color: coral;
}

.content-section {
    display: none;
}

.content-section.active {
    display: block;
}

.row {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin-bottom: 1rem;
}

.column {
    display: flex;
    flex-direction: column;
    flex: 1;
    gap: 1rem;
}

.card {
    background-color: #e0e0e0;
    padding: 1rem;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s, transform 0.3s;
}

.card:hover {
    background-color: #d0d0d0;
    transform: scale(1.05);
}

.table-container {
    flex: 1;
    margin: 0 0.5rem;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background-color: #6200ee;
    color: white;
}

th, td {
    padding: 0.5rem;
    border: 1px solid #ddd;
    text-align: center;
}

tr:hover {
    background-color: #f0f0f0;
}

.app-nav {
    display: flex;
    justify-content: space-around;
    background-color: #f0f0f0;
    padding: 0.5rem 0;
    border-top: 1px solid #ccc;
}

.nav-button {
    background: none;
    border: none;
    padding: 0.5rem;
    text-align: center;
    flex-grow: 1;
    transition: background-color 0.3s, transform 0.3s;
}

.nav-button .icon {
    font-size: 1.5rem;
}

.nav-button .label {
    display: block;
    font-size: 0.75rem;
}

.nav-button:hover {
    background-color: #d0d0d0;
    transform: scale(1.1);
}

.input-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    margin-top: 1rem;
}

input[type="text"] {
    padding: 0.5rem;
}

.countdown {
    font-size: 2rem;
    text-align: center;
    margin-top: 2px;
}

/* Tambahkan di akhir file styles.css */

.trading-history {
    margin-top: 1rem;
}

.trade {
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 1rem;
    margin-bottom: 0.5rem;
    background-color: #f9f9f9;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.trade-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.trade-time {
    font-weight: bold;
    flex: 1;
}

.trade-details {
    flex: 3;
}

.trade-result {
    flex: 1;
    text-align: right;
    color: green; /* Warna hijau untuk keuntungan, bisa disesuaikan */
}

.trade-result.negative {
    color: red; /* Warna merah untuk kerugian, bisa disesuaikan */
}


/* Gaya untuk banner iklan */
.ad-banner {
    max-width: 100%;
    margin: 20px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.ad-link {
    display: flex;
    text-decoration: none;
    color: inherit;
}

.ad-image {
    width: 150px; /* Sesuaikan ukuran gambar sesuai kebutuhan */
    height: auto;
}

.ad-content {
    flex: 1;
    padding: 10px;
}

.ad-title {
    font-size: 1.2rem;
    margin: 0;
}

.ad-description {
    margin: 5px 0;
}

.ad-button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 8px 16px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 14px;
    cursor: pointer;
    border-radius: 3px;
}

.ad-button:hover {
    background-color: #45a049;
}

/* Gaya untuk iklan interstitial */
.interstitial {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8); /* Transparansi latar belakang */
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999; /* Pastikan iklan ini muncul di atas konten lain */
}

.interstitial-link {
    display: flex;
    flex-direction: column;
    text-decoration: none;
    color: inherit;
    text-align: center;
}

.interstitial-image {
    width: 250px; /* Sesuaikan ukuran gambar sesuai kebutuhan */
    height: auto;
    margin-bottom: 20px;
}

.interstitial-content {
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.interstitial-title {
    font-size: 1.5rem;
    margin: 0;
}

.interstitial-description {
    margin: 10px 0;
}

.interstitial-button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
}

.interstitial-button:hover {
    background-color: #45a049;
}


.close-button {
    position: absolute;
    top: 10px;
    right: 10px;
    background-color: transparent;
    border: none;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
}

.close-button:hover {
    color: #ccc;
}

.country-buttons {
    display: flex;
    gap: 15px;
}

.country-button {
    padding: 10px 20px;
    border: 2px solid #007bff;
    background-color: #fff;
    color: #007bff;
    text-transform: uppercase;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    border-radius: 5px;
    font-size: 14px;
}

.country-button:hover {
    background-color: #007bff;
    color: #fff;
    border: 2px solid #0056b3;
}


.country-button.sg { border-color: #ff4081; color: #ff4081; }
.country-button.hk { border-color: #ff9800; color: #ff9800; }
.country-button.sdy { border-color: #4caf50; color: #4caf50; }
.country-button.laos { border-color: #9c27b0; color: #9c27b0; }

.country-button.sg:hover { background-color: #ff4081; border-color: #e91e63; }
.country-button.hk:hover { background-color: #ff9800; border-color: #fb8c00; }
.country-button.sdy:hover { background-color: #4caf50; border-color: #388e3c; }
.country-button.laos:hover { background-color: #9c27b0; border-color: #7b1fa2; }

.country-button.pressed {
    background-color: #d3d3d3; /* Warna latar belakang saat ditekan */
    border: 3px solid #000; /* Border saat ditekan */
    /* Tambahkan gaya lain yang Anda inginkan */
}

.floating-button {
    position: absolute;
    /* top: -30px; */
    left: 50%;
    transform: translateX(-50%);
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 50%;
    width: 60px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 24px;
    cursor: pointer;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    z-index: 10;
    transition: background-color 0.3s;
}

.floating-button:hover {
    background-color: #0056b3;
}

 .form-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            z-index: 20;
        }

        .form-container.active {
            display: block;
        }

        .form-container h2 {
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
        }

        .form-actions button {
            padding: 10px 20px;
            margin-left: 10px;
            cursor: pointer;
        }
        
        
.countdown-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: Arial, sans-serif;
    margin-top: 20px;
}

.end-date {
    font-size: 12px;
    color: gray;
    margin-bottom: 5px;
}

 .whatsapp-button {
            background-color: #25D366;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            display: inline-block;
            transition: background-color 0.3s, transform 0.3s;
        }
        
        .whatsapp-button:hover {
            background-color: #1DA951;
            transform: scale(1.05);
        }
 .alert {
    padding: 20px;
    color: white;
    opacity: 0;
    transition: opacity 0.6s;
    margin-bottom: 15px;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: none;
    z-index: 9999;
    width: 30%;
    max-width: 330px;
    text-align: center;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.success {background-color: #4CAF50;} /* Green */
.info {background-color: #2196F3;} /* Blue */
.warning {background-color: #ff9800;} /* Orange */
.danger {background-color: #f44336;} /* Red */

.closebtn {
    position: absolute;
    top: 5px;
    right: 10px;
    color: white;
    font-size: 20px;
    font-weight: bold;
    cursor: pointer;
}

.closebtn:hover {
    color: black;
}

.dashboard {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
        }
        .balance {
            font-size: 12px;
        }
        .coins {
            font-size: 20px;
            color: black;
            margin-bottom: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            
        }
        .coins img {
            margin-right: 10px;
        }
        .buttons {
            display: flex;
            justify-content: space-between;
        }
        .button {
            background-color: #c7c7c7;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            flex: 1;
            margin: 0 5px;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .button:last-child {
            margin-right: 0;
        }
        .button:first-child {
            margin-left: 0;
        }

        .chart-container {
            width: 100%;
            max-width: 800px;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            text-align: center;
        }
        .title {
            font-size: 12px;
        }
        .inp {
            display: flex;
            justify-content: space-between;
        }
        .input-group {
            flex: 1;
            margin: 0 10px;
        }
        input[type="number"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .multi-buttons {
            display: flex;
            flex-direction: column;
        }
        .multi-button {
            background-color: #6a6b6c;
            color: white;
            border: none;
            padding: 5px;
            font-size: 12px;
            cursor: pointer;
            margin-left: 2px;
            border-radius: 5px;
            margin-bottom: 2px; /* Add space between buttons */
        }
        .multi-button:last-child {
            margin-bottom: 0;
        }
        .multi-button:hover {
            background-color: #0056b3;
        }
        .stop-button {
            background-color: #23c8a9;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            margin: 10px 0;
            width: 100%;
        }
        .stop-button:hover {
            background-color: #c82333;
        }
        .subtitle {
            font-size: 14px;
            color:green;
        }

        .kontr {
            text-align: center;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
        }
        .kontr span {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1em;
            color: #333;
            margin: 0;
        }
        .kontr span img {
            margin-right: 10px;
        }

        .ticker-wrapper {
            width: 100%;
            overflow: hidden;
            background-color: white;
            position: relative;
            height: 30px;
        }
        .ticker {
            display: flex;
            align-items: center;
            position: absolute;
            white-space: nowrap;
            will-change: transform;
        }
        .ticker-item {
            display: flex;
            align-items: center;
            margin-right: 50px;
            font-size: 20px;
        }
        .ticker-item img {
            width: 30px;
            margin-right: 10px;
        }
        .up {
            color: green;
        }
        .down {
            color: red;
        }
   </style>
</head>
<body>
    <div class="app">
        <header class="app-header">
            <h1>Cryptoper</h1>
        </header>
        <div class="dashboard">
            <div class="ticker-wrapper">
                <div id="ticker" class="ticker">
                    <div class="ticker-item">
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5994.png" alt="Coin">
                        <span class="coin-title">Bitcoin</span>
                        <span class="coin-status up">↑ 3000</span>
                    </div>
                    <div class="ticker-item">
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5994.png" alt="Coin">
                        <span class="coin-title">Ethereum</span>
                        <span class="coin-status down">↓ 2300</span>
                    </div>
                    <div class="ticker-item">
                        <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5994.png" alt="Coin">
                        <span class="coin-title">Cardano</span>
                        <span class="coin-status down">↓ 2780</span>
                    </div>
                    <!-- Tambahkan lebih banyak ticker-item jika diperlukan -->
                </div>
            </div>
            <div class="balance">Balance</div>
            <div class="coins"> 
                <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5994.png" />
               
            </div>
            <div class="coins"> 
                <?php if($this->session->userdata('user_logged_in')) { 
                            
                            echo '<h3 id="coin-value" >'. $coin .'</h3>'; 
                        ?>
                        <?php } ?> 
            </div>
            <div class="buttons">
                <button class="button" onclick="contactAgent()">➕</button>
                <button class="button" onclick="contactWD()">📥</button>
                <button class="button">🎁</button>
            </div>
        </div>
        
        <main class="app-content">
            <section class="content-section">
				<div class="country-buttons">

                <!-- <div class="chart-container">
                    <canvas id="tradingChart"></canvas>
                    
                </div> -->

                <div class="kontr">
                    <span><img src="https://s2.coinmarketcap.com/static/img/coins/64x64/5994.png" width="30" /><span id="track-number" style="color:green;">+24,98294453</span></span>
                </div>

				</div>
				<div class="header-row">
                    <h2 class="left">Live</h2>
                    <h2 class="right">
                        <?php if($this->session->userdata('user_logged_in')) { 
                            
                            echo $username; 
                        ?>
                        <a href="<?= base_url('home/logout') ?>" class="logout-button">🔌</a>
                        <?php } ?>
                    </h2>
                </div>
                  
                <div class="container">
                    <div class="title">Bet Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Max Bet</div>
                    <div class="inp">
                        <div class="input-group">
                            <input type="number" id="bet-amount" value="1" min="1" placeholder="Enter amount">
                        </div>
                        <div class="input-group">
                            <input type="number" id="max-bet-amount" value="1" min="1" placeholder="Enter amount">
                        </div>
                    </div>
                    <button class="multi-button" onclick="halfBet()">/2</button>
                    <button class="multi-button" onclick="doubleBet()">x2</button>
                    <button class="multi-button" onclick="maxBet()">Max</button>
                    <br>
                    <?php if($this->session->userdata('user_logged_in')) { ?>
                    <button class="stop-button" onclick="toggleGame()">Bet</button>
                    <?php }else{?>
                    <button class="stop-button" onclick="toggleForm()">Bet</button>
                    <?php }?>
                </div>
				<div class="trading-history" id="tradingHistory">
					<!--<div class="trade">-->
					<!--	<div class="trade-info">-->
					<!--		<div class="trade-username">@Bcs***</div>-->
					<!--		<div class="trade-result">Rp5000</div>-->
					<!--	</div>-->
					<!--</div>-->
				</div>
				
				
            </section>
			<section class="content-section">
                <h2>History</h2>
                	<?php 
				    $user = $this->session->userdata('user_logged_in');
				    if($user){
				?>
				<br>
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Num</th>
                            <th>Bet</th>
                            <th>Result</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($myhistorybet)){ ?>
                        <?php foreach ($myhistorybet as $post): ?>
                            <tr>
                                <td><?php
                            switch ($post->id_category) {
                                case 1:
                                    echo "SG";
                                    break;
                                case 2:
                                    echo "HK";
                                    break;
                                case 3:
                                    echo "SDY";
                                    break;
                                case 4:
                                    echo "LAOS";
                                    break;
                                default:
                                    echo "Unknown";
                            }
                            ?></td>
                                <td><?php echo $post->seo_title; ?></td>
                                <td>Rp.<?php echo $post->content; ?></td>
                                <td>
                                    <?php
                                        $bonusCoin = $post->content * 1.5;
                                        if($post->choice == 'Y'){
                                            echo '<span style="color:green;">Rp.'.$bonusCoin.'</span>';
                                        } else {
                                            echo '<span style="color:red;">Rp.0</span>';
                                        }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php } ?>
                    </tbody>
                </table>
                <?php }?>
                <br>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>City</th>
                                <th>Winning Numbers</th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php if (!empty($historyClose)){ ?>
                        <?php foreach ($historyClose as $post): ?>
                            <tr>
                                <td><?php echo $post->date; ?></td>
                                <td><?php
                            switch ($post->id_category) {
                                case 1:
                                    echo "SG";
                                    break;
                                case 2:
                                    echo "HK";
                                    break;
                                case 3:
                                    echo "SDY";
                                    break;
                                case 4:
                                    echo "LAOS";
                                    break;
                                default:
                                    echo "Unknown";
                            }
                            ?></td>
                                
                                <td><?php echo $post->thread; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php } ?>
                        </tbody>
                    </table>
                </div>
                
            </section>
            <section class="content-section">
                <h2>Box</h2>
                <div class="row">
                    <div class="column">
                        <div class="card">Box 1: 0547</div>
                    </div>
                </div>
            </section>
            <section class="content-section">
                <h2>Check Number</h2>
                <div class="input-group">
                    <label for="checkNumber">Enter Number:</label>
                    <input type="text" id="checkNumber" name="checkNumber">
                    <button onclick="checkNumber()">Check</button>
                </div>
                <div id="checkResult"></div>
            </section>
            <section class="content-section">
                
                <?php if($this->session->userdata('user_logged_in')) { ?>
                    <h2>Profil</h2>
                <p>This is the more section of the mobile-like website.</p>
                <p> <button class="whatsapp-button" onclick="contactAgent()">Contact Agent</button><button class="whatsapp-button" onclick="contactWD()">Withdraw</button></p>
				<?php }else{?>
                    <button class="stop-button" onclick="toggleForm()">Login</button>
                <?php }?>
                <div class="ad-banner">
					<a href="#" class="ad-link">
						<img src="https://asset-a.grid.id/crop/0x0:0x0/x/photo/2021/06/17/dukung-kebutuhan-berinternet-3-20210617025923.jpg" alt="Advertisement" class="ad-image">
						<div class="ad-content">
							<h3 class="ad-title">Special Offer!</h3>
							<p class="ad-description">Save 50% on selected items. Limited time only.</p>
							<button class="ad-button">Shop Now</button>
						</div>
					</a>
				</div>
				<?php 
				    if($user){
				?>
				<div class="user-profile">
                    <h3>User Profile</h3>
                        <div class="form-group row">
                            <label for="username" class="col-sm-3 col-form-label">Username</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo $this->session->userdata('username');?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-sm-3 col-form-label">Email</label>
                            <div class="col-sm-9">
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $this->session->userdata('email');?>">
                            </div>
                        </div>
                </div>
            
                <div class="change-password">
                    <h3>Change Password</h3>
                    <form id="change-password-form">
                        <div class="form-group row">
                            <label for="current-password" class="col-sm-3 col-form-label">Current Password</label>
                            <div class="col-sm-9">
                                <input type="password" class="form-control" id="current-password" name="current-password">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="new-password" class="col-sm-3 col-form-label">New Password</label>
                            <div class="col-sm-9">
                                <input type="password" class="form-control" id="new-password" name="new-password">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
                <?php } ?>

				<!--<div class="interstitial">-->
				<!--	<div class="interstitial-content">-->
				<!--		<button class="close-button" onclick="closeInterstitial()">Close</button>-->
				<!--		<a href="#" class="interstitial-link">-->
				<!--			<img src="path/to/your/image.jpg" alt="Interstitial Advertisement" class="interstitial-image">-->
				<!--			<div class="interstitial-content">-->
				<!--				<h3 class="interstitial-title">Limited Time Offer!</h3>-->
				<!--				<p class="interstitial-description">Get 20% off on all purchases today.</p>-->
				<!--				<button class="interstitial-button">Claim Offer</button>-->
				<!--			</div>-->
				<!--		</a>-->
				<!--	</div>-->
				<!--</div>-->



            </section>
        </main>
        <nav class="app-nav">
            <button class="nav-button" onclick="showSection(0)">
            <span class="icon"><img src="https://cdn-icons-png.flaticon.com/512/4968/4968254.png" width="30"/></span>
                <span class="label">Earn</span>
            </button>
            <button class="nav-button" onclick="showSection(4)">
                <span class="icon">👤</span>
                <span class="label">Profil</span>
            </button>
			
        </nav>
    </div>
    
    <div class="form-container" id="loginForm">
        <button class="close-button" onclick="toggleForm()">×</button>
        <h2>Login</h2>
        <form id="loginFormLevel" action="./home/authenticate" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username_login" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password_login" name="password" required>
            </div>
            <div class="form-actions">
                <button type="submit">Submit</button>
            </div>
        </form>
        <div class="form-group">
            <label for="register">Or Register</label>
            <button onclick="showRegisterForm()">Register</button>
        </div>
    </div>

    <div class="form-container" id="registerFormpanel">
        <button class="close-button" onclick="toggleForm()">×</button>
        <h2>Register</h2>
          <form id="registerForm"  action="./home/register" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username_register" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password_register" name="password" required>
            </div>
            <div class="form-actions">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
    
    <div class="alert success" id="successAlert">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        This is a success!
    </div>

    <div class="alert info" id="infoAlert">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        This is an info!
    </div>

    <div class="alert warning" id="warningAlert">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        This is a warning!
    </div>

    <div class="alert danger" id="dangerAlert">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        This is a Fail!
    </div>


    <div class="alert danger" id="AlertLose">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        You is a Lose!
    </div>

    <div class="alert success" id="AlertWin">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
        You Win!
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
        var h = 23;
        var m = 0;
        var s = 0;
        var d = 0;
        var interval;
        var ca = 1;
        

//         var ctx = document.getElementById('tradingChart').getContext('2d');
// var tradingChart = new Chart(ctx, {
//     type: 'line',
//     data: {
//         labels: [],  // akan diisi dengan label dinamis
//         datasets: [{
//             label: 'Trading Data',
//             backgroundColor: 'rgba(75, 192, 192, 0.2)',
//             borderColor: 'rgba(75, 192, 192, 1)',
//             data: []  // akan diisi dengan data dinamis
//         }]
//     },
//     options: {
//         responsive: true,
//         title: {
//             display: true,
//             text: 'Trading Chart'
//         },
//         tooltips: {
//             mode: 'index',
//             intersect: false,
//         },
//         hover: {
//             mode: 'nearest',
//             intersect: true
//         },
//         scales: {
//             x: {
//                 display: true,
//                 title: {
//                     display: true,
//                     text: 'Time'
//                 },
//                 ticks: {
//                     callback: function(value) {
//                         const date = new Date(value);
//                         return date.getHours().toString().padStart(2, '0') + ':' + date.getMinutes().toString().padStart(2, '0');
//                     }
//                 }
//             },
//             y: {
//                 display: true,
//                 title: {
//                     display: true,
//                     text: 'Value'
//                 }
//             }
//         }
//     }
// });

// // Fungsi untuk mendapatkan data baru
// function getNewData() {
//     const now = new Date();
//     const newValue = Math.floor(Math.random() * 100);  // Simulasi data baru
//     return { time: now, value: newValue };
// }

// // Fungsi untuk memperbarui chart setiap detik
// function updateChart() {
//     const newData = getNewData();

//     // Tambahkan data baru ke chart
//     tradingChart.data.labels.push(newData.time.getTime());
//     tradingChart.data.datasets[0].data.push(newData.value);

//     // Hapus data lama jika lebih dari 15
//     if (tradingChart.data.labels.length > 15) {
//         tradingChart.data.labels.shift();
//         tradingChart.data.datasets[0].data.shift();

//         tradingChart.data.labels.push(newData.time.getTime());
//     tradingChart.data.datasets[0].data.push(newData.value);
//     }

//     // Perbarui chart
//     tradingChart.update();
// }

// // Perbarui chart setiap detik
// setInterval(updateChart, 200);


let previousNumber = 0;

// Fungsi untuk memperbarui angka dan warna teks

        document.addEventListener('DOMContentLoaded', (event) => {
            const buttons = document.querySelectorAll('.country-button');

            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    // Hapus kelas 'pressed' dari semua tombol
                    buttons.forEach(btn => btn.classList.remove('pressed'));

                    // Tambahkan kelas 'pressed' ke tombol yang ditekan
                    this.classList.add('pressed');

                    const country = this.getAttribute('data-country');
                    
                    if(country=="sg"){
                        ca =1;
                    }else if(country=="hk"){
                        ca =2;
                    }else if(country=="sdy"){
                        ca =3;
                    }else if(country=="laos"){
                        ca =4;
                    }

                    // Lakukan aksi sesuai dengan negara yang dipilih
                    console.log(`Button ${country} pressed.`);
                    
                    var tradingHistory = $('#tradingHistory');
                    tradingHistory.empty();
                    
                    var tradeElement = `
                        <div class="trade">
                            <div class="trade-info">
                                <div class="trade-username">Load Please</div>
                                <div class="trade-result">Wait...</div>
                            </div>
                        </div>`;
                    tradingHistory.append(tradeElement);
                });
            });
        });

        document.getElementById('registerForm').addEventListener('submit', function(event) {
            event.preventDefault();
        
            var formData = new FormData(this);
        
            fetch(this.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('successAlert');
                    setTimeout(() => window.location.href = './', 3000);
                } else {
                    showAlert('dangerAlert');
                }
            })
            .catch(error => console.error('Error:', error));
        });
        
        document.getElementById('loginFormLevel').addEventListener('submit', function(event) {
            event.preventDefault();
        
            var formData = new FormData(this);
        
            fetch(this.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('successAlert');
                    setTimeout(() => window.location.href = './', 3000);
                } else {
                    showAlert('dangerAlert');
                }
            })
            .catch(error => console.error('Error:', error));
        });


        $(document).ready(function() {
           const isLoggedInme = <?= json_encode($this->session->userdata('user_logged_in')); ?>;
            
            // function updateCoin() {
            //     $.ajax({
            //         url: '<?= base_url('home/get_user_coin') ?>',
            //         type: 'GET',
            //         dataType: 'json',
            //         success: function(data) {
            //             $('#coin-value').text(data.coin);
            //         }
            //     });
            // }
    
            // // Update coin every 2 seconds
            // if (isLoggedInme) {
            //     setInterval(updateCoin, 2000);
            // }
            
            
            
             $('.country-button').on('click', function() {
            var country = $(this).data('country');
            console.log(country);
                $.ajax({
                    url: '<?= base_url('home/get_end_time') ?>',
                    type: 'GET',
                    data: { name: country },
                    dataType: 'json',
                    success: function(data) {
                        if (data.end_time) {
                            if(data.end_time == "1,1"){
                                const now = new Date();
                                const currentHour = now.getHours() + 1;
                                 $('#endTime').text(currentHour + ":00");
                                 h = currentHour;
                                m = 0;
                                s = 0; // Reset seconds
                                d = 0;
                                 clearInterval(interval);
            
                                // Start the countdown with new values
                                startCountdown();
                            }else{
                                $('#endTime').text(data.end_time);
                                var timeParts = data.end_time.split(':');
                                h = parseInt(timeParts[0]);
                                m = parseInt(timeParts[1]);
                                s = 0; // Reset seconds
                                d = 0;
                                 clearInterval(interval);
            
                                // Start the countdown with new values
                                startCountdown();
                            }
                        } else {
                            alert('End time not found for ' + country);
                        }
                    }
                });
            });
        });
    </script>
    
	<script>
        
        function toggleForm() {
            const isLoggedIn = <?= json_encode($this->session->userdata('user_logged_in')); ?>;
            const loginForm = document.getElementById('loginForm');
            
            if (isLoggedIn) {
                loginForm.classList.remove('active');
            } else {
                loginForm.classList.toggle('active');
            }
        }
        
        function closeBet() {
            const betForm = document.getElementById('betForm');
            
                betForm.classList.remove('active');
        }
        
        function showRegisterForm() {
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerFormpanel');
        
            loginForm.classList.remove('active');
            registerForm.classList.add('active');
        }

        document.addEventListener('DOMContentLoaded', function() {
            showSection(0);
        });

        function showSection(index) {
            const sections = document.querySelectorAll('.content-section');
            sections.forEach((section, i) => {
                section.classList.toggle('active', i === index);
            });
        }


        function startCountdown() {
            const countdownElement = document.getElementById('countdown');
            const now = new Date();
            const targetTime = new Date();
            targetTime.setHours(h, m, s, d); // Set target time to 10 PM

            if (targetTime < now) {
                targetTime.setDate(targetTime.getDate() + 1); // If target time is already past, set for next day
            }

            const countdownDate = targetTime.getTime(); // Define countdownDate here

            function updateCountdown() {
                const now = new Date().getTime();
                const distance = countdownDate - now;

                if (distance <= 0) {
                    countdownElement.textContent = '----';
                    clearInterval(interval);
                    
                    setTimeout(function() {
                        location.reload();
                    }, 30000);
                    
                    return;
                }


                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                countdownElement.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }

            updateCountdown();
            interval = setInterval(updateCountdown, 1000);
        }

        // startCountdown();

        function closeInterstitial() {
            var interstitial = document.querySelector('.interstitial');
            interstitial.style.display = 'none';
        }

        function formatRupiah(input) {
            let value = input.value.replace(/\D/g, '');
            value = (value/1).toFixed(0).replace('.', ',');
            const formatted = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            input.value = formatted;
        }

        function submitBet() {
            const result = document.getElementById('result').value;
            const bet = document.getElementById('bet').value;
            console.log("Bet submitted:", { result, bet });
            toggleForm();
        }

        function contactAgent() {
            const phoneNumber = '6281234567890'; // Ganti dengan nomor telepon agen Anda
            const message = 'Hello, I would like to Deposit.'; // Ganti dengan pesan Anda
            const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
            window.open(url, '_blank');
        }
        
        function contactWD() {
            const phoneNumber = '6281234567890'; // Ganti dengan nomor telepon agen Anda
            const message = 'Hello, I would like to WD Saldo.'; // Ganti dengan pesan Anda
            const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
            window.open(url, '_blank');
        }
        
        
        
        
        function fetchTradingHistory() {
            $.ajax({
                url: '<?= base_url('home/get_trading_history') ?>',
                method: 'GET',
                dataType: 'json',
                data: { ca: ca }, 
                success: function(data) {
                    var tradingHistory = $('#tradingHistory');
                    tradingHistory.empty(); // Hapus konten sebelumnya
                    
                    data.forEach(function(trade) {
                        var tradeTitle = trade.title.substring(0, 3);
                    var tradeElement = `
                        <div class="trade">
                            <div class="trade-info">
                                <div class="trade-username">@${tradeTitle}***</div>
                                <div class="trade-result">Rp${trade.content}</div>
                            </div>
                        </div>`;
                    tradingHistory.append(tradeElement);
                    });
                },
                error: function() {
                    // alert('Failed to fetch trading history.');
                }
            });
        }

        // Panggil fetchTradingHistory saat halaman dimuat
        $(document).ready(function() {
            // fetchTradingHistory();
            
            // Ubah interval untuk memperbarui setiap 3 detik (3000 ms)
            // setInterval(fetchTradingHistory, 3000);
        });
        
        function submitBet() {
            var result = $('#result').val();
            var bet = $('#bet').val().replace(/[^,\d]/g, ''); // Remove formatting before sending

            $.ajax({
                url: '<?= base_url('home/place_bet') ?>',
                method: 'POST',
                dataType: 'json',
                data: {
                    result: result,
                    bet: bet,
                    ca:ca
                },
                success: function(response) {
                    if (response.success) {
                        alert('Bet placed successfully!');
                        toggleForm(); // Close the form
                        location.reload();
                    } else {
                        alert('Failed to place bet.');
                    }
                },
                error: function() {
                    alert('Not Enougt Money.');
                }
            });
        }

        function showAlert(alertId) {
            var alertElement = document.getElementById(alertId);
            alertElement.style.display = 'block';
            setTimeout(function() {
                alertElement.style.opacity = '1';
            }, 10); // start the fade in after a tiny delay

            setTimeout(function() {
                alertElement.style.opacity = '0';
                setTimeout(function() {
                    alertElement.style.display = 'none';
                }, 600); // match this to the transition duration
            }, 1000); // hide after 4 seconds
        }

    </script>


<script>
        const ticker = document.getElementById('ticker');
        let tickerWidth = ticker.offsetWidth;
        let tickerWrapperWidth = ticker.parentElement.offsetWidth;
        let currentTransform = 0;

        function animateTicker() {
            currentTransform -= 1; // Kecepatan scroll
            if (Math.abs(currentTransform) >= tickerWidth) {
                currentTransform = tickerWrapperWidth;
            }
            ticker.style.transform = `translateX(${currentTransform}px)`;
            requestAnimationFrame(animateTicker);
        }

        function updateCoinStatus() {
            const coinStatusElements = document.querySelectorAll('.coin-status');
            coinStatusElements.forEach(statusElement => {
                const isUp = Math.random() > 2;
                statusElement.textContent = isUp ? '↑' : '↓';
                statusElement.className = `coin-status ${isUp ? 'up' : 'down'}`;
            });
        }

        // Mulai animasi ticker
        animateTicker();

        // Perbarui status koin setiap 1 detik
        setInterval(updateCoinStatus, 3000);
    </script>
 
 <script>
        let gameInterval;
        let currentAmount;
        let totalAmount;
        let isPlaying = false;
        let intervalTime = 500; // Start with 500ms

        function halfBet() {
            let betInput = document.getElementById('bet-amount');
            betInput.value = Math.max(1, Math.floor(betInput.value / 2));
        }

        function doubleBet() {
            let betInput = document.getElementById('bet-amount');
            betInput.value = Math.floor(betInput.value * 2);
        }

        function maxBet() {
            let betInput = document.getElementById('bet-amount');
            betInput.value = 100000; // Example max bet
        }

        function toggleGame() {
            if (isPlaying) {
                stopGame();
            } else {
                startGame();
            }
        }

        function startGame() {
            const betInput = parseFloat(document.getElementById('bet-amount').value);
            const coinValueElement = document.getElementById('coin-value');
            let coinValue = parseFloat(coinValueElement.textContent.replace(',', '.'));

            if (betInput <= 0 || coinValue < betInput) {
                alert("Please enter a valid bet amount or check your coin balance.");
                return;
            }else{
                coinValue -= betInput;
                coinValueElement.textContent = coinValue.toFixed(8).replace('.', ',');
    
                currentAmount = betInput;
                isPlaying = true;
                document.getElementById('track-number').textContent = currentAmount.toFixed(8).replace('.', ',');
                document.querySelector('.stop-button').innerText = 'Stop';
    
                updateGame();
            }

            
        }

        function updateGame() {
            gameInterval = setInterval(() => {
                const change = Math.floor(Math.random() * 9 - 4) * 2; // Generate a random number between -8 and 8 in steps of 2
                currentAmount += change;
                const trackNumber = document.getElementById('track-number');
                if (change > 0) {
                    trackNumber.textContent = currentAmount.toFixed(8).replace('.', ',');
                    trackNumber.style.color = 'green';
                } else {
                    trackNumber.textContent = currentAmount.toFixed(8).replace('.', ',');
                    trackNumber.style.color = 'red';
                }

                clearInterval(gameInterval);

                // Reduce interval time but not below 30ms
                intervalTime = Math.max(30, intervalTime * 0.93);
                updateGame();
            }, intervalTime);
        }

        function stopGame() {
            clearInterval(gameInterval);
            isPlaying = false;
            intervalTime = 500; // Reset interval time
            document.querySelector('.stop-button').innerText = 'Bet';

            // Logic to determine win/lose
            const betInput = parseFloat(document.getElementById('bet-amount').value);
            const trackNumber = parseFloat(document.getElementById('track-number').textContent.replace(',', '.'));
            
            // Update coin value display
            const coinValueElement = document.getElementById('coin-value');
            let coinValue = parseFloat(coinValueElement.textContent.replace(',', '.'));
            coinValue += trackNumber;
            coinValueElement.textContent = coinValue.toFixed(8).replace('.', ',');
            
            
            const trackNum = document.getElementById('track-number');
            if (trackNumber > betInput) {
                trackNum.style.color = 'green';
                showAlert('AlertWin');
            } else {
                trackNum.style.color = 'red';
                showAlert('AlertLose');
            }
            
            submitman();
        }
        
        
        function submitman() {
            var result = document.getElementById('coin-value');

            $.ajax({
                url: '<?= base_url('home/placeman') ?>',
                method: 'POST',
                dataType: 'json',
                data: {
                    result: result
                },
                success: function(response) {
                    if (response.success) {
                        console.log('Bet placed successfully!');

                    } else {
                        console.log('Failed to place bet.');
                    }
                },
                error: function() {
                    console.log('Not Enougt Money.');
                }
            });
        }
    </script>
</body>
</html>
