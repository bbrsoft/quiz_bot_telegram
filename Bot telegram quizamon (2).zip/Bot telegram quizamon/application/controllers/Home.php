<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
   
     # https://api.telegram.org/bot7022071551:AAGWEUv8UuzL3W08aUJ35OIHxQku2FBe4zU/setWebhook?url=https://quizamon.rewriter.id/home/webhook
   private $api_token = '7022071551:AAGWEUv8UuzL3W08aUJ35OIHxQku2FBe4zU';
    
     public function __construct()
    {
        parent::__construct();
         // Inisialisasi sesi
        $this->load->library('session');
        $this->load->model('posting_model', 'posting');
        $this->load->model('album_model', 'album');
        $this->load->model('user_model', 'usermodel');
    }

    public function webhook() {
        $update = json_decode(file_get_contents('php://input'), TRUE);
    
        if (isset($update['message'])) {
            $chat_id = $update['message']['chat']['id'];
            $message = $update['message']['text'];
            $user_id = $update['message']['from']['id'];
            $username = $update['message']['from']['username'];
            $language_id = 1;
            $round = 10 ;
            
            $contact_phone_number = 0;
            if (isset($update['message']['contact'])) {
                $contact_phone_number = $update['message']['contact']['phone_number'];
            }
    
            switch ($message) {
                case '/start':
                    if ($this->is_admin($chat_id, $user_id)) {
                        $this->DaftarAdmin($user_id,$chat_id,$username,$contact_phone_number);
                        $this->start_game($chat_id);
                    } else {
                        $this->sendMessage($chat_id, "☝️ Yes, it's my command, but you can use it only within a group chat.");
                    }
                    break;
                    
                case '/start@quizamonbot':
                    if ($this->is_admin($chat_id, $user_id)) {
                        $this->DaftarAdmin($user_id,$chat_id,$username,$contact_phone_number);
                        $this->start_game($chat_id);
                    } else {
                        $this->sendMessage($chat_id, "☝️ Yes, it's my command, but you can use it only within a group chat.");
                    }
                    break;
    
                case '/stop':
                    if ($this->is_admin($chat_id, $user_id)) {
                        $this->stop_game($chat_id);
                    } else {
                        $this->sendMessage($chat_id, "☝️️ Yes, it's my command, but you can use it only within a group chat.");
                    }
                    break;
      
                case '/stop@quizamonbot':
                    if ($this->is_admin($chat_id, $user_id)) {
                        $this->stop_game($chat_id);
                    } else {
                        $this->sendMessage($chat_id, "☝️️ Yes, it's my command, but you can use it only within a group chat.");
                    }
                    break;
                    
                case '/point':
                    if ($this->is_admin($chat_id, $user_id)) {
                        //
                    } else {
                        $coin = $this->usermodel->get_current_coin($user_id);
                        $this->sendMessage($chat_id, "🌟 Your Points Report 🌟

🎉 Hello, <b>".$username."!</b> 🎉

🚀 You have accumulated an impressive number of points! Let's take a look at your point details:

🏅 Current Points: <b>".$coin->coin."</b>

📈 Keep participating in our games and challenges to collect more points and win exciting prizes! 🌟

🔔 Don't forget to stay tuned for our latest updates and weekly challenges! The more active you are, the more points you can gather! 🎁

Thank you for being a part of our community! 😊");
                    }
                    break;
                    
                                case '/point@quizamonbot':
                    if ($this->is_admin($chat_id, $user_id)) {
                        //
                    } else {
                        $coin = $this->usermodel->get_current_coin($user_id);
                        $this->sendMessage($chat_id, "🌟 Your Points Report 🌟

🎉 Hello, <b>".$username."!</b> 🎉

🚀 You have accumulated an impressive number of points! Let's take a look at your point details:

🏅 Current Points: <b>".$coin->coin."</b>

📈 Keep participating in our games and challenges to collect more points and win exciting prizes! 🌟

🔔 Don't forget to stay tuned for our latest updates and weekly challenges! The more active you are, the more points you can gather! 🎁

Thank you for being a part of our community! 😊");
                    }
                    break;
                    
                    
                    case '/invite':
                    if ($this->is_admin($chat_id, $user_id)) {
                        //
                    } else {
                      
                        $this->sendMessage($chat_id, "🌟 3 Reasons to Invite Our Bot to Your Group 🌟

    🏅 Enhance Your Group's Fun!
    Our bot brings exciting games and interactive challenges that will keep everyone entertained and engaged. Boost your group's activity with fun quizzes and contests! 🎉

    🎁 Earn More Rewards!
    By inviting our bot, you and your group members can earn more points and unlock exclusive rewards. The more you play, the more you win! 🏆

    🤖 Easy Setup and Use!
    Adding our bot to your group is simple and quick. Plus, our user-friendly interface ensures that everyone can participate with ease. Get started in just a few clicks! 🚀

👉 Invite the bot now and level up your group experience! 👈");
                    }
                    break;
                    
                                case '/invite@quizamonbot':
                    if ($this->is_admin($chat_id, $user_id)) {
                        //
                    } else {
                      
                        $this->sendMessage($chat_id, "🌟 3 Reasons to Invite Our Bot to Your Group 🌟

    🏅 Enhance Your Group's Fun!
    Our bot brings exciting games and interactive challenges that will keep everyone entertained and engaged. Boost your group's activity with fun quizzes and contests! 🎉

    🎁 Earn More Rewards!
    By inviting our bot, you and your group members can earn more points and unlock exclusive rewards. The more you play, the more you win! 🏆

    🤖 Easy Setup and Use!
    Adding our bot to your group is simple and quick. Plus, our user-friendly interface ensures that everyone can participate with ease. Get started in just a few clicks! 🚀

👉 Invite the bot now and level up your group experience! 👈");
                    }
                    break;
    
                case '/help':
                    $this->help_command($chat_id);
                    break;
                    
                case '/help@quizamonbot':
                    $this->help_command($chat_id);
                    break;
    
                default:
                    $this->handle_message($chat_id, $message, $user_id, $username);
                    $this->answer_quiz($chat_id);
                    break;
            }
        } elseif (isset($update['callback_query'])) {
            $callback_query = $update['callback_query'];
            $chat_id = $callback_query['message']['chat']['id'];
            $user_id = $callback_query['from']['id'];
            $data = $callback_query['data'];
            $message = $callback_query['message']['text'];
            $username = $callback_query['message']['from']['username'];
            
            $contact_phone_number = 0;
            if (isset($callback_query['message']['contact'])) {
                $contact_phone_number = $callback_query['message']['contact']['phone_number'];
            }
            
            
             // Parsing callback_data
            $parts = explode('_', $data);
            $action = $parts[0];
            $round = $parts[2];
            $language_id = $parts[3];
            
            if (strpos($data, 'set_language_') !== false) {
                $language_id = str_replace('set_language_', '', $data);
    
                // Pastikan $language_id lebih besar dari 0
                if (intval($language_id) > 0) {
                    // $this->sendMessage($chat_id, "Debug ID GROUP: ".$chat_id." L:".$language_id." R:".$round);
                    $data_up = array(
                        'jeda' => 0,
                        'l' => $language_id
                    );
            
                    $upRoleStart = $this->usermodel->update_user_start($user_id, $data_up);
                    $this->choose_round($chat_id, $language_id);
                } 
            } elseif (strpos($data, 'set_round_') === 0) {
                 $round = str_replace('set_round_', '', $data);
    
                // Pastikan $language_id lebih besar dari 0
                if (intval($round) > 0) {
                    $data_up = array(
                        'jeda' => 0,
                        'r' => $round
                    );
                
                    $upRoleStart = $this->usermodel->update_user_start($user_id, $data_up);
                    $this->start_quiz($chat_id, $language_id, $round);
                }
                
            } 
        }
    }
    
    
    private function DaftarAdmin($user_id,$chat_id,$username,$contact_phone_number){
         $cekuser = $this->usermodel->checkUser($user_id);
        if (!$cekuser) {
            $hashed_password = password_hash($username, PASSWORD_DEFAULT);
            $created_on = time(); // Menggunakan format Unix timestamp
            $group_idD = "-";
            if($this->isGroupChat($chat_id)){
                $group_idD = $chat_id;
            }
            $data_reg = array(
                'username' => $username,
                'email' => $user_id,
                'password' => $hashed_password,
                'created_on' => $created_on,
                'role' => 'user',
                'phone' => $contact_phone_number,
                'chat_id' =>$chat_id,
                'group_id' =>$group_idD,
                'is_admin' => 1,
                'question_sesi' => 'Open',
                 'jeda' => 0,
                    'l' => 1 ,
                    'r' => 10,
                'status_game' => 0,
                'current_round' => 0,
                'questions' => '',
            );
            
            $this->usermodel->register($data_reg);
        }else{
            if($this->isGroupChat($chat_id)){
                $data_re_up = array(
                    'chat_id' =>$chat_id,
                    'group_id' =>$chat_id,
                );
                $this->usermodel->updatach($user_id,$data_re_up);
            }
        }
    }
    
    private function isGroupChat($chat_id) {
        // Grup biasanya memiliki chat_id negatif
        return $chat_id < 0;
    }
    
    private function sendMessage($chat_id, $text, $keyboard = null) {
        if($this->isGroupChat($chat_id)){
            $url = "https://api.telegram.org/bot" . $this->api_token . "/sendMessage";
            $post_fields = [
                'chat_id' => $chat_id,
                'text' => $text,
                'parse_mode' => 'HTML' 
            ];
            
            if ($keyboard) {
                $post_fields['reply_markup'] = json_encode($keyboard);
            }
    
            $this->httpRequest($url, $post_fields);
        }
    }


    private function httpRequest($url, $post_fields) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_fields));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

    private function is_admin($chat_id, $user_id) {
        $url = "https://api.telegram.org/bot" . $this->api_token . "/getChatAdministrators?chat_id=" . $chat_id;
        $result = json_decode(file_get_contents($url), TRUE);
        foreach ($result['result'] as $admin) {
            if ($admin['user']['id'] == $user_id) {
                return TRUE;
            }
        }
        return FALSE;
    }

    private function start_game($chat_id) {
        $languages = $this->album->getAlb();
        
        $language_buttons = [];
        foreach ($languages as $language) {
            $language_buttons[] = [
                'text' => $language->album_name,
                'callback_data' => 'set_language_' . $language->id
            ];
        }
        
        
        $keyboard = [
            'inline_keyboard' => array_chunk($language_buttons, 2)
        ];
        
        $this->sendMessage($chat_id, "❗️ I m Quizamon bot, and I play Quizamon. Choose Language:", $keyboard);
    }

    private function choose_round($chat_id, $language_id) {
        if ($language_id === null) {
            return;
        }
    
        $round_buttons = [
            ['text' => '10', 'callback_data' => 'set_round_10_' . $language_id],
            ['text' => '20', 'callback_data' => 'set_round_20_' . $language_id],
            ['text' => '30', 'callback_data' => 'set_round_30_' . $language_id],
            ['text' => '40', 'callback_data' => 'set_round_40_' . $language_id],
             ['text' => '50', 'callback_data' => 'set_round_50_' . $language_id],
        ];
        
        
        $keyboard = [
            'inline_keyboard' => array_chunk($round_buttons, 2)
        ];
        
        $this->sendMessage($chat_id, " Choose Number of Rounds:", $keyboard);
    }


    private function start_quiz($chat_id, $language_id, $rounds) {
        
        $dataMi = $this->usermodel->dataMis($chat_id);
        $jeda = $dataMi['jeda'];
        $question_sesi = $dataMi['question_sesi'];
        $language_id  = $dataMi['l'];
        $rounds = $dataMi['r'];
        
        $cekQuext = $this->session->userdata('questions');
        if (empty($cekQuext)) {
         $questions = $this->posting->get_questions($language_id, $rounds);
           $this->session->set_userdata('questions', $questions);
        }
        
        if ($question_sesi == 'Open') {
            if($jeda==0){
                $this->sendMessage($chat_id, "🏁 Your Ready .. !! ");
            }
        }
            $this->next_question($chat_id,$language_id,$rounds);
        
    }


    
    private function next_question($chat_id,$language_id,$rounds) {
        // $this->sendMessage($chat_id, "Debug: Q , ID GROUP: ".$chat_id);
        
        $dataMi = $this->usermodel->dataMis($chat_id);
        $question_sesi = $dataMi['question_sesi'];
        if ($question_sesi != 'Open') {
            return; // Hentikan jika sesi tidak terbuka
        }
        
        $questions = $this->session->userdata('questions');
        $jeda = $dataMi['jeda'];
        $current_round = $dataMi['current_round'];
        $l = $dataMi['l'];
        $r = $dataMi['r'];
        $jawaban_kosong = $dataMi['jawaban_kosong'];
        $user_answer = $this->usermodel->dataAnswer($chat_id);
        $score = $dataMi['score'];
        
        $user_ans = $this->usermodel->dataAns($chat_id);
        
        if ($user_ans) {
            $data = array(
                'jawaban_kosong' => 'ada'
            );
        
            // Gunakan model untuk memperbarui tabel users
            $this->usermodel->update_user_fields($chat_id, $data);
        }
        
        if($jawaban_kosong=='' && $current_round>=3){
            $this->jawabankosong($chat_id);
        }else{
    
            if ($current_round < count($questions) && $question_sesi == 'Open') {
                $question = $questions[$current_round];
                $answer = $question->title;
                $hidden_answer = str_repeat('_ ', strlen($answer));
                
                if($jeda==0){
                    // Tampilkan pertanyaan pertama kali
                    $message = "<b>Round " . ($current_round + 1) . "/" . count($questions) . "</b>\n";
                    $message .= "▶️ " . $question->content . "\n";
                    $message .= "Hint: " . $hidden_answer . "\n";
                    $message .= "<b>[ . . o o o o o o ]</b>";
                    $this->sendMessage($chat_id, $message);
                    $this->answer_quiz($chat_id);
                } elseif ($jeda==1){
                    
                    
                    $nobody = true; // Inisialisasi sebagai true terlebih dahulu
                    $questions = $this->session->userdata('questions');
                    
                    foreach ($user_answer as $answerloop) {
                        if ($answerloop['user_answer'] == $answer) {
                            // Perbarui current_round
                            $current_round++;
                            
                                // Ambil nilai dari session
                            $jeda = 0;
                           $newscore = isset($score) ? $score : ''; // Inisialisasi $newscore jika belum diinisialisasi
                            
                            // Tambahkan nilai baru ke $newscore
                            $newscore = empty($newscore) ? $answerloop['username'] : $newscore . "," . $answerloop['username'];
    
                    
                            // Buat array data yang berisi nilai-nilai yang akan diperbarui
                            $data = array(
                                'jeda' => $jeda,
                                'status_game' => 0,
                                'current_round' => $current_round,
                                'score' => $newscore
                            );
                
                            // Gunakan model untuk memperbarui tabel users
                            $this->usermodel->update_user_fields($chat_id, $data);
                            $this->sendMessage($chat_id, "✅ <b> Yes, " . $answer . "! </b>  \n " . $answerloop['username'] . " Correct! +10 point.   ");
                             $current_coin_data = $this->usermodel->get_current_coin($answerloop['email']);
        
                            // Tambahkan 10 ke nilai coin saat ini
                            $new_coin = $current_coin_data->coin + 10;
                            $new_answer = $current_coin_data->answer + 1;
                    
                            // Buat array data yang berisi nilai-nilai yang akan diperbarui
                            $data = array(
                                'coin' => $new_coin,
                                'answer' => $new_answer
                            );
                    
                            // Gunakan model untuk memperbarui tabel users
                            $this->usermodel->update_user_fields($chat_id, $data);
                            $data = array(
                                    'user_answer' => ''
                                );
                                $this->usermodel->update_an_kosong($chat_id, $data);
                       
                             // Set nobody ke false karena ada yang benar
                               $cekRound = $current_round ;
                            if ($cekRound >= count($questions)) {
                                $data = array(
                                    'question_sesi' => 'Closed'
                                );
                                $this->usermodel->update_user_fields($chat_id, $data);
                                $this->end_quiz($chat_id);
                            } else {
                                $dataMi = $this->usermodel->dataMis($chat_id);
                                $question_sesi = $dataMi['question_sesi'];
                                if ($question_sesi == 'Open') {
                                    $this->next_question($chat_id, $l, $r);
                                }
                            }
                            break;
                        }
                    }
                    
            
                    $clue = $this->get_clue($answer, 5);
                    $message = "<b>Round " . ($current_round + 1) . "/" . count($questions) . "</b>\n";
                    $message .= "▶️ " . $question->content . "\n";
                    $message .= "Hint: " . $clue . "\n";
                    $message .= "<b>[ . . . . . o o o ]</b>";
                    $this->sendMessage($chat_id, $message);
            
                    
                    $this->answer_quiz($chat_id);
                }elseif ($jeda==2){
                    $nobody = true; // Inisialisasi sebagai true terlebih dahulu
                    $questions = $this->session->userdata('questions');
                    
                    foreach ($user_answer as $answerloop) {
                        if ($answerloop['user_answer'] == $answer) {
                            // Perbarui current_round
                            $current_round++;
                            
                                // Ambil nilai dari session
                            $jeda = 0;
                             $newscore = isset($score) ? $score : ''; // Inisialisasi $newscore jika belum diinisialisasi
                            
                            // Tambahkan nilai baru ke $newscore
                            $newscore = empty($newscore) ? $answerloop['username'] : $newscore . "," . $answerloop['username'];
    
                            // Buat array data yang berisi nilai-nilai yang akan diperbarui
                            $data = array(
                                'jeda' => $jeda,
                                'status_game' => 0,
                                'current_round' => $current_round,
                                'score' => $newscore
                                
                            );
                
                            // Gunakan model untuk memperbarui tabel users
                            $this->usermodel->update_user_fields($chat_id, $data);
                            $this->sendMessage($chat_id, "✅ <b> Yes, " . $answer . "! </b>  \n " . $answerloop['username'] . " Correct! +10 point.   ");
                             $current_coin_data = $this->usermodel->get_current_coin($answerloop['email']);
        
                            // Tambahkan 10 ke nilai coin saat ini
                            $new_coin = $current_coin_data->coin + 10;
                            $new_answer = $current_coin_data->answer + 1;
                    
                            // Buat array data yang berisi nilai-nilai yang akan diperbarui
                            $data = array(
                                'coin' => $new_coin,
                                'answer' => $new_answer
                            );
                    
                            // Gunakan model untuk memperbarui tabel users
                            $this->usermodel->update_user_fields($chat_id, $data);
                            
                            
                            $nobody = false;
                           
                             // Set nobody ke false karena ada yang benar
                            break;
                        }
                    }
                    
                    if ($nobody) {
                        // Perbarui current_round
                        $current_round++;
                        
                            // Ambil nilai dari session
                            $jeda = 0;
                    
                            // Buat array data yang berisi nilai-nilai yang akan diperbarui
                            $data = array(
                                'jeda' => $jeda,
                                'current_round' => $current_round
                            );
                
                            // Gunakan model untuk memperbarui tabel users
                            $this->usermodel->update_user_fields($chat_id, $data);
                        $this->sendMessage($chat_id, "⛔️ Nobody guessed. The correct answer was <b>" . $answer . "</b>");
                        
                     
                
                    }
                    $data = array(
                        'user_answer' => ''
                    );
                    $this->usermodel->update_an_kosong($chat_id, $data);
                     $cekRound = $current_round ;
                    if ($cekRound >= count($questions)) {
                        $data = array(
                            'question_sesi' => 'Closed'
                        );
                        $this->usermodel->update_user_fields($chat_id, $data);
                        $this->end_quiz($chat_id);
                    } else {
                        $dataMi = $this->usermodel->dataMis($chat_id);
                        $question_sesi = $dataMi['question_sesi'];
                        if ($question_sesi == 'Open') {
                            $this->next_question($chat_id, $l, $r);
                        }
                    }
        
                }
                
            }
        
        }
    }

    
    private function get_clue($answer, $reveal_count) {
        $clue = str_split($answer);
        for ($i = 0; $i < count($clue); $i++) {
            if ($i % $reveal_count != 0) {
                $clue[$i] = '_ ';
            }
        }
        return implode('', $clue);
    }


    
     private function answer_quiz($chat_id) {
        $data = array(
            'question_sesi' => 'Closed'
        );

        // Gunakan model untuk memperbarui tabel users
        $this->usermodel->update_user_fields($chat_id, $data);
        
     }
     
     
    private function end_quiz($chat_id) {
        $this->session->sess_destroy();
        $dataMi = $this->usermodel->dataMis($chat_id);
        $question_sesi = $dataMi['question_sesi'];
        if($question_sesi == "Closed"){
            
            $topranking = $this->usermodel->get_ranking_top_datatables();
             $score = isset($dataMi['score']) ? $dataMi['score'] : 0;
            
             if (empty($score)) {
                    $message = "Quiz finished! No Rank\n\n";
                } else {
                    // Pisahkan skor berdasarkan koma dan hitung frekuensi setiap nilai
                    $scoreArray = explode(',', $score);
                    $scoreCounts = array_count_values($scoreArray);
                    
                    // Urutkan nilai berdasarkan frekuensi, dari yang tertinggi ke terendah
                    arsort($scoreCounts);
                    
                    // Buat pesan ranking
                    $message = "Quiz finished! Here are the rankings:\n\n";
                    $rank = 1;
                    foreach ($scoreCounts as $name => $count) {
                        $points = $count * 10; // Setiap kemunculan dihitung 10 poin
                        $medal = '';
                        switch ($rank) {
                            case 1: $medal = '🏆'; break;
                            case 2: 
                            case 3: $medal = '🎖'; break;
                            case 4:
                            case 5: $medal = '🏅'; break;
                            default: $medal = '🔸';
                        }
                        $message .= "{$rank}. {$name} - {$points} points {$medal}\n";
                        $rank++;
                    }
                }
            
                $this->sendMessage($chat_id, $message);
        
            // Memeriksa apakah ada data dalam $topranking
            if (!empty($topranking)) {
                $rankingMessage = "🎉 Global ranking (week)\n";
        
                // Loop melalui $topranking untuk membangun pesan
                foreach ($topranking as $index => $user) {
                    $position = $index + 1;
                    $medal = '';
                    switch ($position) {
                        case 1: $medal = '🏆'; break;
                        case 2: 
                        case 3: $medal = '🎖'; break;
                        case 4:
                        case 5: $medal = '🏅'; break;
                        default: $medal = '🔸';
                    }
        
                    $rankingMessage .= " {$medal} {$position}. {$user->username}   {$user->coin} points (answers: {$user->answer})\n";
                }
        
                $rankingMessage .= "\nTo get rankings information at any time, write me in private chat: @Quizamon";
        
                // Mengirim pesan ranking
                $this->sendMessage($chat_id, $rankingMessage);
                        
                         $data = array(
                    'question_sesi' => 'Open',
                    'score' =>''
                );
        
                // Gunakan model untuk memperbarui tabel users
                $this->usermodel->update_user_fields($chat_id, $data);
            } else {
                $this->sendMessage($chat_id, "No ranking data available.");
            }
            
            // Reset session untuk pertanyaan, skor, dan ronde
            
        }
        
        
        $data = array(
            'jeda' => 0,
            'l' => 1,
            'r' => 10,
            'status_game' => 0,
            'current_round' => 0,
            'jawaban_kosong' =>''
        );

        // Gunakan model untuk memperbarui tabel users
        $this->usermodel->update_user_fields($chat_id, $data);
       
    }
    
    private function handle_message($chat_id, $message, $user_id,$username) {
        // $data = array(
        //     'question_sesi' => 'Open'
        // );
        // $this->usermodel->update_user_fields($chat_id, $data);
        
        $coin = $this->usermodel->get_current_coin($user_id);
        $newAnsw = $coin->answer + 1;
        $time = time();
         $data = array(
            'user_answer' => $message,
            'time_answer' => $time,
            'answer' =>$newAnsw,
            'group_id' =>$chat_id
            
        );

        // Gunakan model untuk memperbarui tabel users
        $this->usermodel->update_user_jawab($user_id, $data);
        
    }

    private function jawabankosong($chat_id) {
        $this->session->sess_destroy();
        // Reset session untuk pertanyaan, skor, dan ronde
        // Buat array data yang berisi nilai-nilai yang akan diperbarui
                $data = array(
                    'jeda' => 0,
                    'l' => 1,
                    'r' => 10,
                    'status_game' => 0,
                    'current_round' => 0,
                    'questions' => '',
                    'score' => '',
                    'question_sesi' => 'Open'
                );
        
                // Gunakan model untuk memperbarui tabel users
                $this->usermodel->update_user_fields($chat_id, $data);
             $this->sendMessage($chat_id, "💤 You don't seem to be playing, I will stop bugging you for now.
If you want to keep playing, just say /start");
        $this->sendMessage($chat_id, "🏁 Weirdly, nobody won. On the bright side, nobody lost either!");
    }

    private function stop_game($chat_id) {
        $this->session->sess_destroy();
        // Reset session untuk pertanyaan, skor, dan ronde
        // Buat array data yang berisi nilai-nilai yang akan diperbarui
                $data = array(
                    'jeda' => 0,
                    'l' => 1,
                    'r' => 10,
                    'status_game' => 0,
                    'current_round' => 0,
                    'questions' => '',
                    'question_sesi' => 'Open',
                    'jawaban_kosong' => ''
                );
        
                // Gunakan model untuk memperbarui tabel users
                $this->usermodel->update_user_fields($chat_id, $data);
                
        $this->sendMessage($chat_id, "🏁 Weirdly, nobody won. On the bright side, nobody lost either!");
    }
    
    public function get_users() {
        $data = $this->usermodel->get_data_chat_p();
        header('Content-Type: application/json');
        echo json_encode($data);
    }
    
    public function send_start_command() {
        $chat_id = $this->input->post('chat_id');
        $dataMi = $this->usermodel->dataMis($chat_id);
        $l = $dataMi['l'];
        $r = $dataMi['r'];
        $jedas = $dataMi['jeda'];
        $statusgame = $dataMi['status_game'];
        $question_sesi = $dataMi['question_sesi'];
        if ($question_sesi == 'Closed') {
            if($jedas==0 && $statusgame==0){
                $data = array(
                    'jeda' => 1,
                    'question_sesi' => 'Open'
                );
        
                // Gunakan model untuk memperbarui tabel users
                $this->usermodel->update_user_fields($chat_id, $data);
            }else if($jedas==1){
                $data = array(
                    'jeda' => 2,
                    'question_sesi' => 'Open'
                );
        
                // Gunakan model untuk memperbarui tabel users
                $this->usermodel->update_user_fields($chat_id, $data);
            }
        }
       
        $this->start_quiz($chat_id,  $l, $r);
        echo true;
    }

    private function help_command($chat_id) {
        $this->sendMessage($chat_id, "❗️ I'm Quizamon bot, and I play Quizamon.

Quizamon is like trivia because it's about your knowledge. Quizamon is unlike trivia because you don't have answer options. But you've got unlimited number of attempts!

The rules are simple: /invite I give you the question, and you and your friends have one minute to answer it. Time to time I will give you hints by revealing some of the letters of the word or words.

Whoever answers first, wins the round. If several people answer almost simultaneously, all of them win. The faster you answer the more points you get.

The number of answering attempts is unlimited, you are not penalized in any way for answering incorrectly. So unleash your fantasy and keep trying!

My supported commands are:
  /start - starts the game
  /stop - stops the game (the game will also stop automatically if nobody's playing for 3 rounds)
  /help - to display this message
  /point - Current Points.
  

If you want to run your own Quizamon channel
  1. Make the channel a supergroup
  2. Post /start
  3. The channel will enter perpetual mode: it won't stop after 5 rounds for inactivity, and non-admins won't be able to stop the game.");
    }
    
    
    public function blogg(){
        $data['page'] = 'blog';
      $this->load->view('front/layouts/app', $data);
    }

}

/* End of file Home.php */
