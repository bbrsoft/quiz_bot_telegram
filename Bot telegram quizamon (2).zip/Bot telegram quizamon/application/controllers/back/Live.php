<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

    var $table = 'album';
   var $id = 'id';
   var $tableJoin = '';
   var $column_order = ['album_name', 'album_seo', 'photo']; // Kolom untuk sorting
   var $column_search = ['album_name', 'album_seo']; // Kolom untuk pencarian
   var $order = ['id' => 'asc']; // Default sorting

   public function __construct()
   {
      parent::__construct();
      $this->load->model('album_model', 'album');
   }

   public function ajax_list()
   {
      $list = $this->album->get_datatables();
      $data = [];
      $no = $_POST['start'];
      
      foreach($list as $li){
         $no++;
         $row = [];
         $row[] = $no++;
         $row[] = $li->username;
         $row[] = 
         '<a class="btn btn-sm btn-success text-white" href="#" 
         title="Edit" onclick="edit_member('."'" . $li->id . "'".')">
         <i class="fa fa-coins mr-1"></i> Add Coin</a>';
         $data[] = $row;
      }

      $output = [
         "draw" => $_POST['draw'],
         "recordsTotal" => $this->album->count_all(),
         "recordsFiltered" => $this->album->count_filtered(),
         "data" => $data,
      ];
      
      echo json_encode($output);
   }

   public function get_data()
    {
        $id = $this->input->post('id', true);
        $data = $this->user->get_by_id($id);
        echo json_encode($data);
    }
    
    public function update()
    {
        // Validasi form di sini
        $this->form_validation->set_rules('coin', 'Coin', 'required|numeric');
    
        if ($this->form_validation->run() != false) {
            $coin = $this->input->post('coin', true);
            $id = $this->input->post('id', true);
            
            // Persiapkan data untuk diupdate
            $data = [
                'coin' => $coin
            ];
            
            // Update koin di database
            $this->user->update($id, $data);
            
            echo json_encode(['status' => TRUE]);
        } else {
            echo json_encode(['status' => FALSE, 'message' => validation_errors()]);
        }
    }


}

/* End of file Identity.php */