<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class History_model extends CI_Model {
    public function checkgroup($chat_id) {
        $this->db->where('chat_id', $chat_id);
        $query = $this->db->get('history_answer');

        return ($query->num_rows() > 0); // Mengembalikan boolean langsung
    }
    
    public function dataMis($chat_id){
        $this->db->select('*');
        $this->db->from('history_answer');
        $this->db->where('chat_id', $chat_id);
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array(); // Mengembalikan satu baris sebagai array
    }
   
    public function AddnewGroup($data){
        return $this->db->insert('history_answer', $data);
    }
    
    public function UpsesiGroup($data_group, $chat_id) {
        // Lakukan update sesuai dengan kolom yang ada di tabel 'history_answer'
        $this->db->where('chat_id', $chat_id);
        return $this->db->update('history_answer', $data_group);
    }
}