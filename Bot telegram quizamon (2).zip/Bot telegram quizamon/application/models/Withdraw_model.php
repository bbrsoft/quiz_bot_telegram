<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Withdraw_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
        // Set additional data
        $data['date'] = date('Y-m-d H:i:s');
        $data['status'] = 'pending'; // Default status
        $data['date_verify'] = null; // Verification date, initially null

        // Insert data into the database
        return $this->db->insert('withdraw', $data);
    }
}
?>
