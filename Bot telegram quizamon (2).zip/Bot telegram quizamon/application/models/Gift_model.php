<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gift_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function save($data) {
        $data['date'] = date('Y-m-d H:i:s');
        $data['status'] = 'pending';
        $data['date_verify'] = null;

        return $this->db->insert('gifts', $data);
    }

    public function get_by_code($code) {
        $this->db->where('unique_code', $code);
        return $this->db->get('gifts')->row_array();
    }
}
?>
