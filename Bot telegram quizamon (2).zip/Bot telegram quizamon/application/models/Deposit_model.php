<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Deposit_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Save deposit data
    public function save($data) {
        $data['date'] = date('Y-m-d H:i:s');
        $data['status'] = 'pending'; // Default status
        
        return $this->db->insert('deposit', $data);
    }
}
?>
