<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    
    
    private function _get_datatables_query()
   {
      $this->db->from($this->table);

      $i = 0;
      foreach ($this->column_search as $item) // loop kolom yang dibutuhkan untuk pencarian
      {
         if($_POST['search']['value']) // jika datatable mengirimkan pencarian dengan metode POST
         {
            if($i===0) // looping pertama
            {
               $this->db->group_start(); // open bracket. query Where dengan OR clause lebih baik dengan group start dan end.
               $this->db->like($item, $_POST['search']['value']);
            }
            else
            {
               $this->db->or_like($item, $_POST['search']['value']);
            }

            if(count($this->column_search) - 1 == $i) // looping terakhir
               $this->db->group_end(); // close bracket
         }
         $i++;
      }

      if(isset($_POST['order'])) // here order processing
      {
         $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
      } 
      else if(isset($this->order))
      {
         $order = $this->order;
         $this->db->order_by(key($order), $order[key($order)]);
      }
   }

   function get_datatables()
   {
      $this->_get_datatables_query();
      if($_POST['length'] != -1)
      $this->db->where('role <>', 'Admin');
      $this->db->limit($_POST['length'], $_POST['start']);
      $query = $this->db->get();
      return $query->result();
   }
   
   function get_ranking_datatables()
   {
      $this->_get_datatables_query();
      if($_POST['length'] != -1)
      $this->db->order_by('coin', 'DESC');
      $this->db->where('role <>', 'Admin');
      $this->db->limit($_POST['length'], $_POST['start']);
      $query = $this->db->get();
      return $query->result();
   }
   
    public function checkUser($user_id) {
        $this->db->where('email', $user_id);
        $query = $this->db->get('users');

        if ($query->num_rows() > 0) {
            return true; // Pengguna sudah ada
        } else {
            return false; // Pengguna belum ada
        }
    }
   
   function get_ranking_top_datatables()
   {
        $this->db->from('users');
        $this->db->where('role <>', 'Admin'); // Memfilter pengguna dengan role selain 'Admin'
        $this->db->order_by('coin', 'DESC');  // Mengurutkan berdasarkan coin dalam urutan menurun
        $this->db->limit(10);                 // Mengambil 10 pengguna teratas
        $query = $this->db->get();
    
        return $query->result();
   }

   function count_filtered()
   {
      $this->_get_datatables_query();
      $query = $this->db->get();
      return $query->num_rows();
   }
   
    public function get_current_coin($user_id) {
        $this->db->select('coin, answer');
        $this->db->from('users');
        $this->db->where('email', $user_id); // Pastikan 'user_id' adalah kolom di tabel 'users'
        $query = $this->db->get();
    
        if ($query->num_rows() > 0) {
            return $query->row(); // Mengembalikan seluruh objek baris
        } else {
            // Jika tidak ada data, asumsikan 0 untuk coin dan answer
            return (object) ['coin' => 0, 'answer' => 0];
        }
    }
    
    
    
    public function dataMis($chat_id){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('group_id', $chat_id);
        $this->db->where('is_admin', 1);
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->row_array(); // Mengembalikan satu baris sebagai array
    }
    
    public function dataAnswer($chat_id){
         $this->db->select('*');
        $this->db->from('users');
        $this->db->where('group_id', $chat_id);
        $this->db->order_by('time_answer', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function dataAns($chat_id) {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_answer','<>', '');
        $this->db->where('group_id', $chat_id);
        $query = $this->db->get();
    
        if ($query->num_rows() > 0) {
            return true;
        }
        return false;
    }
    
    public function update_an_kosong($chat_id,$data){
         $this->db->where('group_id', $chat_id);
        return $this->db->update('users', $data);
    }
    
    public function update_user_start($user_id, $data) {
        $this->db->where('email', $user_id);
        // $this->db->where('is_admin', 1);
        return $this->db->update('users', $data);
    }
   
    public function update_user_fields($chat_id, $data) {
        $this->db->where('group_id', $chat_id);
        $this->db->where('is_admin', 1);
        return $this->db->update('users', $data);
    }
    
     public function update_user_jawab($user_id, $data) {
        $this->db->where('email', $user_id);
        return $this->db->update('users', $data);
    }
    
    
    
    
    public function updatach($user_id,$data){
        $this->db->where('email', $user_id);
        return $this->db->update('users', $data);
    }
    
    
    public function AddnewGroup($data){
        return $this->db->insert('users', $data);
    }
    

   public function count_all()
   {
      $this->db->from($this->table);
      return $this->db->count_all_results();
   }
    
    public function login($username, $password) {
        $this->db->where('username', $username);
        $query = $this->db->get('users');
        
        if ($query->num_rows() == 1) {
            $user = $query->row();
            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        return false;
    }

    
    public function register($data) {
        return $this->db->insert('users', $data);
    }
    
    
     public function get_data_chat_p() {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('group_id !=', 0);
        $this->db->where('question_sesi', 'Closed');
        $this->db->where('is_admin', 1);
        $this->db->limit(10);
        $query = $this->db->get();
        return $query->result();
    }

    public function upPointUser($user_id) {
        $amount = 10;
        $p = 1;
        $this->db->set('coin', 'coin + ' . $amount, FALSE);
        $this->db->set('answer', 'answer + ' . $p, FALSE);
        $this->db->where('email', $user_id);
        $this->db->update('users');
    }
    
    public function get_by_id($id) {
          $this->db->where('id', $id);
          return $this->db->get('users')->row();
      }
      
      
    public function updateUserCoin($username, $amount) {
        $this->db->set('coin', 'coin + ' . $amount, FALSE);
        $this->db->where('username', $username);
        $this->db->update('users');
    }
  
    public function get_coin_by_id($id)
    {
        $this->db->select('coin');
        $this->db->from('users');
        $this->db->where('id', $id);
        $query = $this->db->get();
    
        if ($query->num_rows() > 0) {
            return $query->row()->coin;
        } else {
            return 0; // Atau nilai default lainnya
        }
    }
    
    public function update($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('users', $data);
    }
    
    public function get_user_by_username($username) {
        $this->db->where('username', $username);
        $query = $this->db->get('users');
        return $query->row();
    }

    public function update_coin($username, $new_coin) {
        $this->db->where('username', $username);
        $this->db->update('users', ['coin' => $new_coin]);
    }


}
