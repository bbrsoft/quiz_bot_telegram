<?php
// Token Bot dari BotFather
$botToken = "7022071551:AAFk4Mj3byLpGgxPc62QbctFQXa9gG2e6wI";
$apiURL = "https://api.telegram.org/bot$botToken/";

include_once 'db.php';
include_once 'UserModel.php';
include_once 'PostingModel.php';
include_once 'AlbumModel.php';

// Mendapatkan update dari webhook
$update = file_get_contents('php://input');
$updateArray = json_decode($update, TRUE);

// Inisialisasi koneksi database dan model
$database = new Database();
$db = $database->getConnection();
$userModel = new UserModel($db);
$postingModel = new PostingModel($db);
$albumModel = new AlbumModel($db);

if (isset($updateArray['message'])) {
    handleMessage($updateArray['message']);
} elseif (isset($updateArray['callback_query'])) {
    handleCallbackQuery($updateArray['callback_query']);
}

function handleMessage($message) {
    global $apiURL, $userModel;

    $chat_id = $message['chat']['id'];
    $text = $message['text'];
    $user_id = $message['from']['id'];
    $username = $message['from']['username'];

    $contact_phone_number = 0;
    if (isset($message['contact'])) {
        $contact_phone_number = $message['contact']['phone_number'];
    }

    DaftarAdmin($user_id, $chat_id, $username, $contact_phone_number);

    switch ($text) {
        case '/start':
            start_game($chat_id);
            break;
        case '/stop':
            stop_game($chat_id);
            break;
                    
        case '/myclaim':
        case '/myclaim@QuizMillionBot':
                $coin = $userModel->get_current_coin($user_id);
                if ($coin->coin != 0) {
                    $formatted_coin = number_format($coin->coin, 0, ',', '.');
                    sendMessage($chat_id, "🌟 Your Points Claim Report 🌟
                
🎉 Hello, <b>".$username."!</b> 🎉

🚀 You have accumulated an impressive number of points! Let's take a look at your point details:

🏅 Current Points: <b>".$formatted_coin."</b>

📈 Keep participating in our games and challenges to collect more points and win exciting prizes! 🌟

🔔 Don't forget to stay tuned for our latest updates and weekly challenges! The more active you are, the more points you can gather! 🎁

/wd You Wanna /Withdraw money let Report Claim Money

Thank you for being a part of our community! 😊");
                }else{
                    sendMessage($chat_id, "No Claim Report
                
🎉 , <b>".$username."!</b> 🎉");
                }
            break;
                    
                
                    
        case '/Withdraw':
            $coin = $userModel->get_current_coin($user_id);
            if ($coin->coin != 0) {
                $formatted_coin = number_format($coin->coin, 0, ',', '.');
                sendMessage($chat_id, "🎉 Congratulations! You have successfully earned a reward of
          
<b>".$formatted_coin."</b>!
          
🎊 To withdraw, please click the following link to make the payment to the admin: [Payment Link](https://app.sandbox.midtrans.com/payment-links/1722681648576) 💳.

Please fill out the form with the following details:
- 📝 Name
- 📞 Phone Number
- 📧 Email

Thank you! 🙏");
}
            break;
    
        case '/help':
        case '/help@QuizMillionBot':
            help_command($chat_id);
            break;
        default:
            handle_message_client($chat_id, $text, $user_id, $username);
            answer_quiz($chat_id);
            break;
    }
}

function handleCallbackQuery($callback_query) {
    global $userModel, $postingModel;

    $chat_id = $callback_query['message']['chat']['id'];
    $user_id = $callback_query['from']['id'];
    $data = $callback_query['data'];
    $username = $callback_query['from']['username'];

    $contact_phone_number = 0;
    if (isset($callback_query['message']['contact'])) {
        $contact_phone_number = $callback_query['message']['contact']['phone_number'];
    }

    $language_id = null; // Inisialisasi $language_id

    if (strpos($data, 'set_language_') !== false) {
        $language_id = str_replace('set_language_', '', $data);

        if (intval($language_id) > 0) {
            choose_round($chat_id, $language_id);
        }
    } elseif (strpos($data, 'set_round_') === 0) {
        // Pisahkan $data untuk mendapatkan nilai round dan language_id
        $parts = explode('_', str_replace('set_round_', '', $data));
        if (count($parts) === 2) {
            list($round, $language_id) = $parts;
    
            if (intval($language_id) > 0 && intval($round) > 0) { // Pastikan $language_id dan $round ada
                $questions = $postingModel->get_questions($language_id, intval($round));
                $question_ids = array_column($questions, 'id');
                $questions_str = implode(',', $question_ids);
                $data_up = array(
                    'jeda' => 0,
                    'r' => intval($round),
                    'l' => intval($language_id),
                    'questions' => $questions_str,
                    'question_sesi' =>'Open'
                );
    
                $userModel->update_user_fields($user_id, $data_up);
                start_game_round($chat_id, $language_id, intval($round));
            }
        }
    }
}

function stop_game($chat_id) {
    global $userModel;
    // Reset session untuk pertanyaan, skor, dan ronde
    // Buat array data yang berisi nilai-nilai yang akan diperbarui
            $data = array(
                'jeda' => 0,
                'l' => 1,
                'r' => 10,
                'status_game' => 0,
                'current_round' => 0,
                'questions' => '',
                'question_sesi' => 'End',
                'jawaban_kosong' => ''
            );
    
            // Gunakan model untuk memperbarui tabel users
            $userModel->update_user_fields($chat_id, $data);
            
    sendMessage($chat_id, "🏁 Weirdly, nobody won. On the bright side, nobody lost either!");
}


function DaftarAdmin($user_id, $chat_id, $username, $contact_phone_number) {
    global $userModel;

    $user_exists = $userModel->checkUser($user_id);

    if (!$user_exists) {
        $hashed_password = password_hash($username, PASSWORD_DEFAULT);
        $created_on = time(); 
        $group_idD = "-";

        $data_reg = [
            'username' => $username,
            'email' => $user_id,
            'password' => $hashed_password,
            'created_on' => $created_on,
            'phone' => $contact_phone_number,
            'chat_id' => $chat_id,
            'group_id' => $group_idD
        ];

        $userModel->register($data_reg);
    }
}

function start_game($chat_id) {
    global $albumModel;
    
    // Ambil semua data album
    $dataalbum = $albumModel->getAlb();
    
    $language_buttons = [];

    // Loop melalui setiap album dan tambahkan tombol ke array
    foreach ($dataalbum as $album) {
        $language_buttons[] = [
            'text' => $album['album_name'], // Akses menggunakan indeks array
            'callback_data' => 'set_language_' . $album['id']
        ];
    }

    // Buat keyboard inline, dua tombol per baris
    $keyboard = [
        'inline_keyboard' => array_chunk($language_buttons, 2)
    ];

    // Kirim pesan dengan keyboard inline
    sendMessage($chat_id, "❗️ I’m Quizamon bot, and I play Quizamon. Choose Language:", $keyboard);
}


function choose_round($chat_id, $language_id) {
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => '10', 'callback_data' => 'set_round_10_' . $language_id],
                ['text' => '20', 'callback_data' => 'set_round_20_' . $language_id],
            ],
            [
                ['text' => '30', 'callback_data' => 'set_round_30_' . $language_id],
                ['text' => '40', 'callback_data' => 'set_round_40_' . $language_id],
            ],
            [
                ['text' => '50', 'callback_data' => 'set_round_50_' . $language_id],
            ],
        ]
    ];

    sendMessage($chat_id, "Choose Number of Rounds :", $keyboard);
}

function start_game_round($chat_id, $language_id, $round) {
    global $userModel;
    $dataMi = $userModel->dataMis($chat_id);
    $jeda = $dataMi['jeda'];
    $question_sesi = $dataMi['question_sesi'];
    $language_id  = $dataMi['l'];
    $rounds = $dataMi['r'];
    
    if ($question_sesi == 'Open') {
        // if($jeda==0){
            sendMessage($chat_id, "🏁 Your Ready .. !! ",null);
        // }
    }
    next_question($chat_id, $language_id, $round);  // Memulai dari ronde 1
}

function next_question($chat_id, $language_id, $round) {
    global $userModel;
    global $postingModel;

    $dataMi = $userModel->dataMis($chat_id);
    $question_sesi = $dataMi['question_sesi'];
    if ($question_sesi != 'Open') {
        return; // Hentikan jika sesi tidak terbuka
    }
    
    $questions_str = $dataMi['questions']; // String ID yang dipisahkan oleh koma
    $question_ids = explode(',', $questions_str);
    $jeda = $dataMi['jeda'];
    $current_round = $dataMi['current_round'];
    
    $l = $dataMi['l'];
    $r = $dataMi['r'];
    $user_answer = $userModel->dataAnswer($chat_id);
    $score = $dataMi['score'];
    
    
    
    if ($current_round < $round && $question_sesi == 'Open') {
        $idPertanyaan = 1;
        if (isset($question_ids[$current_round])) {
            $idPertanyaan = $question_ids[$current_round];
        }
        
        $question = $postingModel->ambilpertanyaan($idPertanyaan);
        if ($question !== null) {
            $answer = $question['title'];
            $content = strip_tags($question['content']);
            $hidden_answer = str_repeat('_ ', strlen($answer));
        } 
        
        // sendMessage($chat_id, "Cek Jeda ->".$jeda,null);
        
        if($jeda==0){
            
            $message = "<b>Round " . ($current_round + 1) . "/" . $round . "</b>\n";
            $message .= "▶️ " . $content. "\n";
            $message .= "Hint: " . $hidden_answer . "\n";
            $message .= "<b>[ . . o o o o o o ]</b>";
            sendMessage($chat_id, $message,null);
            answer_quiz($chat_id);
            
        } else if ($jeda==1) {
            
            foreach ($user_answer as $answerloop) {
                if ($answerloop['user_answer'] == $answer) {
                    // Perbarui current_round
                    $current_round++;
                    $jeda = 0;
                    if (!is_numeric($score)) {
                        $score = 0;
                    }
                    
                    $newscore = $score;
                    
                    // Pastikan bahwa $question_coins[$current_round] adalah angka sebelum ditambahkan
                    if (isset($question_coins[$current_round]) && is_numeric($question_coins[$current_round])) {
                        $newscore += $question_coins[$current_round];
                    }
                    
                    $data = array(
                        'jeda' => 0,
                        'current_round' => $current_round,
                        'question_sesi' => 'Open',
                        'score' => $newscore
                    );
                    $userModel->update_user_fields($chat_id, $data);
                    
                    sendMessage($chat_id, "✅ <b> Yes, " . $answer . "! </b>  \n " . $answerloop['username'] . " Correct! +10 point.   ");
                    // $nobody = false; // Setel menjadi false jika ada yang menjawab benar
                     $current_coin_data = $userModel->get_current_coin($answerloop['email']);
                    $new_coin = $current_coin_data->coin + 10;
                    $new_answer = $current_coin_data->answer + 1;
                    $data = array(
                        'coin' => $new_coin,
                        'answer' => $new_answer
                    );
                    $userModel->update_user_fields($chat_id, $data);
                    $data = array(
                        'user_answer' => ''
                    );
                    $userModel->update_an_kosong($chat_id, $data);
                    $cekRound = $current_round ;
                    if ($cekRound >= $round) {
                        $data = array(
                            'question_sesi' => 'Closed'
                        );
                        $userModel->update_user_fields($chat_id, $data);
                        end_quiz($chat_id);
                    } else {
                        $dataMi = $userModel->dataMis($chat_id);
                        $question_sesi = $dataMi['question_sesi'];
                        if ($question_sesi == 'Open') {
                            next_question($chat_id, $l, $r);
                        }
                    }
                    break;
                }
            }
            
            
            $clue = get_clue($answer, 5);
            $message2 = "<b>Round " . ($current_round + 1) . "/ ". $round ." </b>\n";
            $message2 .= "▶️ " . $content . "\n";
            $message2 .= "Hint: " . $clue . "\n";
            $message2 .= "<b>[ . . . . . o o o ]</b>";
            sendMessage($chat_id, $message2,null);
            answer_quiz($chat_id);
        } else if ($jeda==2) {
            $nobody = true; // Inisialisasi sebagai true terlebih dahulu
            
            foreach ($user_answer as $answerloop) {
                if ($answerloop['user_answer'] == $answer) {
                    $current_round++;
                    $jeda = 0;
                    $newscore = isset($score) ? $score : '';
                    $newscore = empty($newscore) ? $answerloop['username'] : $newscore . "," . $answerloop['username'];
                    $data = array(
                        'jeda' => $jeda,
                        'status_game' => 0,
                        'current_round' => $current_round,
                        'score' => $newscore
                        
                    );
                    $userModel->update_user_fields($chat_id, $data);
                    sendMessage($chat_id, "✅ <b> Yes, " . $answer . "! </b>  \n " . $answerloop['username'] . " Correct! +10 point.   ");
                     $current_coin_data = $userModel->get_current_coin($answerloop['email']);
                    $new_coin = $current_coin_data->coin + 10;
                    $new_answer = $current_coin_data->answer + 1;
                    $data = array(
                        'coin' => $new_coin,
                        'answer' => $new_answer
                    );
                    $userModel->update_user_fields($chat_id, $data);
                    
                    
                    $nobody = false;
                    break;
                }
            }
            
            if ($nobody) {
                $current_round++;
                $jeda = 0;
                $data = array(
                    'jeda' => $jeda,
                    'current_round' => $current_round
                );
                $userModel->update_user_fields($chat_id, $data);
                sendMessage($chat_id, "⛔️ Nobody guessed. The correct answer was <b>" . $answer . "</b>",null);
                
            }
            
            // $data = array(
            //     'user_answer' => ''
            // );
            
            // $userModel->update_an_kosong($chat_id, $data);
             $cekRound = $current_round ;
            if ($cekRound == $round) {
                end_quiz($chat_id);
            } else {
            //     $dataMi = $userModel->dataMis($chat_id);
                // $question_sesi = $dataMi['question_sesi'];
                // if ($question_sesi == 'Open') {
                    next_question($chat_id, $l, $r);
                // }
            }
        } 
    }
    // $userModel->update_user_fields($chat_id, array('jawaban_kosong' => '', 'user_answer' => ''));
    
}


function get_clue($answer, $reveal_count) {
    $clue = str_split($answer);
    for ($i = 0; $i < count($clue); $i++) {
        if ($i % $reveal_count != 0) {
            $clue[$i] = '_ ';
        }
    }
    return implode('', $clue);
}

function answer_quiz($chat_id) {
    global $userModel;
    $dataMi = $userModel->dataMis($chat_id);
    $je = $dataMi['jeda'];
    $question_sesi = $dataMi['question_sesi'];
    // sendMessage($chat_id, "Cek Jeda A->".$je);
    
    if($question_sesi=='Open'){
        $jeda =$je + 1;
        $data = array(
            'question_sesi' => 'Closed',
            'jeda' => $jeda
        );
    
        // Gunakan model untuk memperbarui tabel users
        $userModel->update_user_fields($chat_id, $data);
    }
    
 }
 
 function end_quiz($chat_id) {
    global $userModel;
    
    // sendMessage($chat_id, "OVER END ".$chat_id);
    
    $dataMi = $userModel->dataMis($chat_id);
    $question_sesi = $dataMi['question_sesi'];
    // if($question_sesi == "Open"){
        
        
        //  $score = isset($dataMi['score']) ? $dataMi['score'] : 0;
        
        //  if (empty($score)) {
        //         $message = "Quiz finished! No Rank\n\n";
        //     } else {
        //         // Pisahkan skor berdasarkan koma dan hitung frekuensi setiap nilai
        //         $scoreArray = explode(',', $score);
        //         $scoreCounts = array_count_values($scoreArray);
                
        //         // Urutkan nilai berdasarkan frekuensi, dari yang tertinggi ke terendah
        //         arsort($scoreCounts);
                
        //         // Buat pesan ranking
        //         $message = "Quiz finished! Here are the rankings:\n\n";
        //         $rank = 1;
        //         foreach ($scoreCounts as $name => $count) {
        //             $points = $count * 10; // Setiap kemunculan dihitung 10 poin
        //             $medal = '';
        //             switch ($rank) {
        //                 case 1: $medal = '🏆'; break;
        //                 case 2: 
        //                 case 3: $medal = '🎖'; break;
        //                 case 4:
        //                 case 5: $medal = '🏅'; break;
        //                 default: $medal = '🔸';
        //             }
        //             $message .= "{$rank}. {$name} - {$points} points {$medal}\n";
        //             $rank++;
        //         }
        //     }
        
        //     sendMessage($chat_id, $message);
    
        $topranking = $userModel->get_ranking_top_datatables();
        if (!empty($topranking)) {
            $rankingMessage = "🎉 Global ranking (week)\n";
        
            foreach ($topranking as $index => $user) {
                $position = $index + 1;
                $medal = '';
                switch ($position) {
                    case 1: $medal = '🏆'; break;
                    case 2: 
                    case 3: $medal = '🎖'; break;
                    case 4:
                    case 5: $medal = '🏅'; break;
                    default: $medal = '🔸';
                }
        
                $rankingMessage .= " {$medal} {$position}. {$user['username']}   {$user['coin']} points (answers: {$user['answer']})\n";
            }
        
            $rankingMessage .= "\nTo get rankings information at any time, write me in private chat: @Quizamon";
        
            // Mengirim pesan ranking
            sendMessage($chat_id, $rankingMessage);
            }else {
                sendMessage($chat_id, "No ranking data available.");
            }
                    
                $data = array(
                    'jeda' => 0,
                    'l' => 1,
                    'r' => 10,
                    'status_game' => 0,
                    'current_round' => 0,
                    'questions' => '',
                    'score' => '',
                    'question_sesi' => 'End',
                    'user_answer' => ''
                );
        
                // Gunakan model untuk memperbarui tabel users
                $userModel->update_user_fields($chat_id, $data);
                    // Reset session untuk pertanyaan, skor, dan ronde
                    
        // }
        }

 
 function jawabankosong($chat_id,$money) {
     global $userModel;
        // Reset session untuk pertanyaan, skor, dan ronde
        // Buat array data yang berisi nilai-nilai yang akan diperbarui
                $data = array(
                    'jeda' => 0,
                    'l' => 1,
                    'r' => 10,
                    'status_game' => 0,
                    'current_round' => 0,
                    'questions' => '',
                    'score' => '',
                    'question_sesi' => 'Open'
                );
        
                // Gunakan model untuk memperbarui tabel users
                $userModel->update_user_fields($chat_id, $data);
             sendMessage($chat_id, "😢 You lost ". $money ."! Better luck next time!, I will stop bugging you for now.
If you want to keep playing, just say /start 

Info type /help");
        sendMessage($chat_id, "🏁 Weirdly, nobody won. On the bright side, nobody lost either!");
    }

function help_command($chat_id) {
    $response = "❗️ I'm Quizamon bot, and I play Quizamon.

Quizamon is like trivia because it's about your knowledge. Quizamon is unlike trivia because you don't have answer options. But you've got unlimited number of attempts!

The rules are simple: /invite I give you the question, and you and your friends have one minute to answer it. Time to time I will give you hints by revealing some of the letters of the word or words.

Whoever answers first, wins the round. If several people answer almost simultaneously, all of them win. The faster you answer the more points you get.

The number of answering attempts is unlimited, you are not penalized in any way for answering incorrectly. So unleash your fantasy and keep trying!

My supported commands are:
  /start - starts the game
  /stop - stops the game (the game will also stop automatically if nobody's playing for 3 rounds)
  /help - to display this message
  /point - Current Points.
  

If you want to run your own Quizamon channel
  1. Make the channel a supergroup
  2. Post /start
  3. The channel will enter perpetual mode: it won't stop after 5 rounds for inactivity, and non-admins won't be able to stop the game.";
    sendMessage($chat_id, $response);
}

function sendMessage($chat_id, $message, $keyboard = null) {
    global $apiURL;

    $data = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];

    if ($keyboard) {
        $data['reply_markup'] = json_encode($keyboard);
    }

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $apiURL . "sendMessage");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);

    return $response;
}


// Periksa apakah method diatur
if (isset($_GET['method'])) {
    $method = $_GET['method'];

    switch ($method) {
        case 'send_start_command':
            if (isset($_POST['chat_id'])) {
                $chat_id = $_POST['chat_id'];
                send_start_command($chat_id);
            } else {
                echo json_encode(['error' => 'Chat ID is required']);
            }
            break;

        case 'get_users':
            get_users();
            break;

        default:
            echo json_encode(['error' => 'Invalid method']);
            break;
    }
} 

function get_users() {
    global $userModel;

    // Set header JSON sebelum output lain
    header('Content-Type: application/json');

    $data = $userModel->get_data_chat_p();
    
    // Output JSON
    if (empty($data)) {
        echo json_encode(['error' => 'No data found']);
    } else {
        echo json_encode($data);
    }
}


function handle_message_client($chat_id, $text, $user_id,$username) {
        global $userModel;
        
        $coin = $userModel->get_current_coin($user_id);
        if (!empty($coin)) {
            $firstRow = $coin[0]; // Ambil baris pertama dari array
            $newAnsw = $firstRow['answer'] + 1;
        }
        $time = time();
        $data = array(
            'user_answer' => $text,
            'time_answer' => $time,
            'answer' =>$newAnsw,
            'chat_id' =>$chat_id,
            'question_sesi' => 'Closed'
            
        );

        // Gunakan model untuk memperbarui tabel users
        $userModel->update_user_jawab($user_id, $data);
        
    }

    
    function send_start_command($chat_id) {
        global $userModel;
        $dataMi = $userModel->dataMis($chat_id);
        $l = $dataMi['l'];
        $r = $dataMi['r'];
        // $statusgame = $dataMi['status_game'];
        $question_sesi = $dataMi['question_sesi'];
        
        if($question_sesi=='Closed'){
        
            $data = array(
                'question_sesi' => 'Open'
            );
                // Gunakan model untuk memperbarui tabel users
             $userModel->update_user_fields($chat_id, $data);
        }

        next_question($chat_id,  $l, $r);
        echo true;
    }

?>
