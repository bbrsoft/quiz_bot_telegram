<?php
class AlbumModel {
    private $conn;
    private $table_name = "album";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAlb() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();
        $albums = [];
        while ($row = $result->fetch_assoc()) {
            $albums[] = $row;
        }
        $stmt->close();
        return $albums;
    }
}
?>